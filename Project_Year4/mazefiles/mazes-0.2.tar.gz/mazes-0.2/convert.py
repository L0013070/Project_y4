#!/usr/bin/env python
#
# convert.py - convert an ascii drawing into maze data.
#
# Written by:  C W Rose
#
# Version 0.2 of 1 March 2011.
#
# ### Add the .mz2 output file format.
#
"""Convert an ASCII maze map to the binary .maz format.

This is the long usage message placeholder.
"""

import binascii
import ctypes
import os
import struct
import sys
import linecache
import re
from optparse import OptionParser

# Global constants.
OK = 1
FAILED = -1
# Maze directions; used to index into Directions.
(BAD, UP, RIGHT, DOWN, LEFT) = (0, 1, 2, 4, 8)
Directions = ("BAD", "UP", "RIGHT", " ", "DOWN", " ", " ", " ", "LEFT")

# Global variables.
VERSION = "0.2"
VERSION_ID = "Version 0.2 dated 1 Mar 2011"
Flags = {}  # Program flags.
Maze = []   # Maze description.

#
# r e a d _ o n e
#
# Read a maze file in the (ascii) local format and write a maz file.
#
# Returns:  Nothing     Always
#
def read_one(infp, outfp):
    """Docstring placeholder.
    """
    global Flags, Maze

    height = 0
    width = 0
    index = 0
    # ### Arbitrary initialisation size.
    Maze = [0 for j in range(512)]
    for line in infp:
        # Skip comments and empty lines.
        if line[0] == "#" or line[0] == "\n":
            continue
        # Get the line number
        r = re.split('"', line)
        height = int(r[2][4:])
        #print "H %d" % height
        # Get the start of the map
        if height == -1:
            width = len(r[1])
        if len(r[1]) != width:
            print "Bad line", str(r[0])
        # Update the map array
        for j in range(17):
            # Get the left-hand edge.
            if j == 0:
                v = 0
                c = r[1][j]
                if c == "|":
                    v |= LEFT
            # Tiles are described by pairs of characters.
            else:
                c = r[1][j * 2 - 1]
                d = r[1][j * 2]
                if c == "_":
                    v |= DOWN
                if d == "|":
                    v |= RIGHT
                if index > 0 and (Maze[index - 1] & RIGHT):
                    v |= LEFT
                if index > 15 and Maze[index - 16] & DOWN:
                    v |= UP
                Maze[index] = v
                v = 0
                index += 1

        begin = (height + 1) * 16
        end = (height + 2) * 16

        # Used for debugging only.
        if Flags["dbg"]:
            print >> sys.stderr, "+%s+" % r[1]
            for k in range(begin, end):
                print >> sys.stderr, k, Maze[k],
            print >> sys.stderr

    # Check the result.
    maze = Maze[16:272]
    rc = checkmaze(maze)

    # Print the output in the required format, skipping the first line.
    begin = 16
    end = 272
    s = ""
    for m in range(begin, end):
        s += chr(Maze[m])
    outfp.write(s)
    if Flags["vrb"]:
        for m in range(begin, end):
             print >> sys.stdout, "%2d," % Maze[m],
        print >> sys.stdout

    return

#
# r e a d _ t w o
#
# Read a maze file in the (ascii) micromaze format and write a maz file.
#
# Returns:  Nothing     Always
#
def read_two(infp, outfp):
    """Docstring placeholder.
    """
    global Flags, Maze

    first = True
    index = 0
    iswall = False
    # ### Arbitrary initialisation size.
    Maze = [0 for j in range(512)]
    for line in infp:
        # Skip comments and empty lines.
        if line[0] == "#" or line[0] == "\n":
            continue
        # Stripping the newline makes dumps easier to read.
        clean = line.rstrip()
        #print "@%s@" % clean
        if len(clean) != 33:
            print "Bad line index %d length %d" % (index, len(clean))
            return
        # Skip the first line, which is always a wall.
        if first:
            first = False
            continue

        # Update the map array, 32 lines of 34 chars.
        iswall = not iswall
        # Get L-R edges.
        if iswall:
            for j in range(17):
                # Get the left-hand edge.
                if j == 0:
                    v = 0
                    c = clean[j]
                    if c == "|":
                        v |= LEFT
                # Tiles are described by pairs of characters.
                else:
                    c = clean[j * 2 - 1]
                    d = clean[j * 2]
                    if d == "|":
                        v |= RIGHT
                    if index > 0 and (Maze[index - 1] & RIGHT):
                        v |= LEFT
                    Maze[index] = v
                    v = 0
                    index += 1
        # Get U-D edges.
        else:
            for j in range(17):
                if j == 0:
                    if index > 15:
                        index = index - 16
                # Tiles are described by pairs of characters.
                else:
                    v = Maze[index]
                    c = clean[j * 2 - 1]
                    d = clean[j * 2]
                    if c == "-":
                        v |= DOWN
                    if index < 16:
                        v |= UP
                    if index > 15 and Maze[index - 16] & DOWN:
                        v |= UP
                    Maze[index] = v
                    v = 0
                    index += 1

        # Dump the current line and its conversion.
        begin = index - 16
        end = index
        if Flags["dbg"]:
            print >> sys.stderr, "+%s+" % clean
            for m in range(begin, end):
                print >> sys.stderr, m, Maze[m],
            print >> sys.stderr

        # Quit after the last pair of lines.
        if not iswall and index == 256:
            break

    # Check the result.
    rc = checkmaze(Maze)

    # Print the output in the required format.
    s = ""
    for m in range(0, 256):
        s += chr(Maze[m])
    outfp.write(s)
    if Flags["vrb"]:
        for m in range(0, 256):
            print >> sys.stdout, "%2d," % Maze[m],
        print >> sys.stdout
    # Used for debugging only.
    if False:
        for m in range(0, 256):
            print >> sys.stderr, "%3d %s" % (m, readable(Maze[m])),
            if m % 16 == 15:
                print >> sys.stderr

    return

#
# r e a d _ b i n
#
# Read a binary (maz) file and write it out in the local ascii format.
#
# Returns:  Nothing     Always
#
def read_bin(infp, outfp):
    """Docstring placeholder.
    """
    global Flags, Maze

    Maze = [0 for j in range(256)]
    buff = infp.read(256)
    if len(buff) != 256:
        print >> sys.stderr, "Wrong file size %d bytes" % len(buff)
        return

    # Convert characters to integers.
    for j in range(256):
        Maze[j] = ord(buff[j])

    # Check the result.
    rc = checkmaze(Maze)

    # Draw the top wall.
    s = ""
    for j in range(16):
        c = " "
        d = " "
        if Maze[j] & UP:
            d = "_"
        s = s + c + d
    print s

    # Draw the rest of the maze.
    for base in range(16):
        s = "|"
        for j in range(16):
            c = " "
            d = " " 
            if Maze[base * 16 + j] & DOWN:
                c = "_"
            if Maze[base * 16 + j] & RIGHT:
                d = "|"
            s = s + c + d
        print s
    print

    return

#
# c h e c k m a z e
#
# Check that a binary array is a valid maze.
#
# Returns:  True    Valid maze
#           False   Invalid maze
#
def checkmaze(maze):
    """Docstring placeholder.
    """
    rc = True
    # Check each tile against those adjacent.
    for base in range(16):
        for j in range(16):
            index = base * 16 + j
            if j == 0 and not maze[index] & LEFT:
                print >> sys.stderr, "Missing left wall at tile %d" % index
                rc = False
            if j > 0:
                if maze[index] & LEFT and not maze[index - 1] & RIGHT:
                    print >> sys.stderr, "Mismatched left wall at tile %d" % index
                    rc = False
            if j == 15 and not maze[index] & RIGHT:
                print >> sys.stderr, "Missing right wall at tile %d" % index
                rc = False
            if base == 0 and not maze[index] & UP:
                print >> sys.stderr, "Missing upper wall at tile %d" % index
                rc = False
            if base > 0:
                if maze[index] & UP and not maze[index - 16] & DOWN:
                    print >> sys.stderr, "Mismatched upper wall at tile %d" % index
                    rc = False
            if base == 15 and not maze[index] & DOWN:
                print >> sys.stderr, "Missing lower wall at tile %d" % index
                rc = False

    return rc

#
# r e a d a b le
#
# Produce a readable string from a binary tile value
#
# Returns:  a string    Always
#
def readable(tile):
    """Docstring placeholder.
    """
    s = ""
    for d in (UP, RIGHT, DOWN, LEFT):
        if tile & d:
            s += " "
            s += Directions[d]
    if s == "":
        s = " NONE"
    s += ","
    return s

#
# m a i n
#
# Main function of convert.py
#
# Returns:  0   Success
#           2   Failure
#
def main(argv=None):
    """Docstring placeholder.
    """
    global Flags, Maze

    # Set default flag values
    Flags["dbg"] = False
    #Flags["maz"] = False
    Flags["vrb"] = False

    # If no file argument is given, take input from stdin and
    # write to stdout; otherwise use the file names provided.
    #
    # The OptionParser module has the built-in options -h and --help
    # and defines 'prog'
    # Use the -m flag to change the output to the  .mz2 file format.
    #
    #usage = "usage: %prog -t 1|2|3 [-d] [-h] [-i file] [-m] [-o file] [-v] - convert maze data"
    usage = "usage: %prog -t 1|2|3 [-d] [-h] [-i file] [-o file] [-v] - convert maze data"
    version = "%prog: " + VERSION_ID
    parser = OptionParser(usage=usage, version=version)
    parser.set_defaults(debug=False,ftype=0,verbose=False)
    parser.add_option("-d", "--debug", action="store_true", dest="debug",
                    help="print debugging messages")
    parser.add_option("-i", "--infile", dest="infile",
                    help="read data from FILE", metavar="FILE")
    #parser.add_option("-m", "--maz", action="store_true", dest="maz",
    #                help="output in maz file format")
    parser.add_option("-o", "--outfile", dest="outfile",
                    help="write data to FILE", metavar="FILE")
    parser.add_option("-t", "--type", action="store", type="int", dest="ftype",
                    help="set the input file type (1-local,2-micromouse,3-maz)",
                    metavar="TYPE")
    parser.add_option("-v", "--verbose", action="store_true", dest="verbose",
                    help="print status messages")

    # Fetch command line options.
    if argv is None:
        argv = sys.argv

    # Run the parser.
    (options, args) = parser.parse_args()

    # Update the global flag dictionary.
    if options.debug: Flags["dbg"] = True
    #if options.maz: Flags["maz"] = True
    if options.verbose: Flags["vrb"] = True

    # Used for debugging only.
    #print "Verbose is ", str(Flags["vrb"])
    #print "Number of arguments remaining", len(args)

    # Check the arguments.
    status = OK

    ftype = options.ftype
    if ftype != 1 and ftype != 2 and ftype != 3:
        print "Unknown file type %d" % ftype
        status = FAILED

    infp = sys.stdin
    if (options.infile and options.infile != "-"):
        try:
            infp = open(options.infile, 'r')
        except IOError:
            print "Cannot open input file %s" % options.infile
            status = FAILED
    else:
        pass

    outfp = sys.stdout
    if (status == OK and options.outfile and options.outfile != "-"):
        try:
            outfp = open(options.outfile, 'w')
        except IOError:
            print "Cannot open output file %s" % options.outfile
            status = FAILED
    else:
        pass

    # Run main loop
    if (status == OK):
        if ftype == 1:
            read_one(infp, outfp)
        elif ftype == 2:
            read_two(infp, outfp)
        elif ftype == 3:
            read_bin(infp, outfp)
        else:
            print >> sys.stderr, "Unknown file type %d" % ftype

    # Wrap up and quit
    infp.close()
    outfp.close()

    return 0

#
# Run the main program if necessary.
#
if __name__ == "__main__":
    sys.exit(main())

#
# eof
#


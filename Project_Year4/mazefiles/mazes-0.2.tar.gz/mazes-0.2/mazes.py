#!/usr/bin/env python
#
# maze.py - solve MicroMouse mazes using various algorithms.
#
# Version 0.2 of 1 September 2011.
#
# Tested under Linux and Python 2.7.
#
# TODO:
# ### Review tiles delete operation.
# ### Should Cairo/Pango contexts and layouts be destroyed?
#
# The Wall Follower Algorithm
#
# If there's a space to the right then go right,
# otherwise if there's a space ahead then go ahead,
# otherwise if there's a space to the left then go left,
# otherwise backtrack.
#
# Essentially, keep the right (or the left) wall to one side.
# This algorithm will solve only those mazes whose walls are
# all connected to the boundary.
#
# The Flood Fill Algorithm.
# While the current tile is not the target:
#    Mark the current tile.
#    Check each adjacent tile in turn, and move to the first unmarked tile.
#    If all adjacent tiles are marked, backtrack to the current tiles' parent.
#
# Modified Flood Fill Algorithm.
#
# If a cell is not the destination cell, its value should be one plus
# the minimum value of its open neighbours. If updating a cell's value
# causes its neighbors to break the "1 + min value" rule, the neighbours
# must be checked as well.
# Once the cell values have been updated, the mouse can once again follow
# the distance values in descending order. So the modified flood-fill
# procedure for updating the distance values is:
#
# Most of the time, the modified flood-fill is faster than the regular
# flood-fill, since it updates a limited set of values.
#
# The A* Algorithm
#
# 1. Add the starting node to the open list.
# 2. Repeat the sequence:
#    Look for the lowest G (cost to reach) + H (heuristic) node on the open list.
#    Move this node to the closed list.
#    For each adjacent node repeat the sequence:
#      If it is not accessible, or on the closed list, ignore it.
#      If it isn't on the open list, add it. Update its parent and cost fields.
#      If it's on the open list, check its G cost.  If the new G cost is
#      lower than the current G cost, the new path is better. Update the parent
#      and cost fields, and rebuild the open queue.
# 3. Terminate when either the target node is on the closed list (success),
#    or the open list is empty (failure).
# 4. Run back down the parent list to the starting node to obtain the path.
#
# If h is monotone, or consistent, such that h(x) <= h(y) + d(x,y) for every
# edge x,y, then Dijkstra's algorithm can be used at a reduced cost.
#
# Tremaux' algorithm
#
# This method is similar to the recursive backtracker and will find a solution
# for all mazes.
# Leave the start vertex from any edge.
# At each vertex, reached by edge E, proceed as follows:
#     If the vertex V has not been visited before:
#         If there is an usused edge, leave by it.
#         If there is no unused edge, leave by E.
#     If vertex V has been visited before:
#         If E has just been used for the first time, leave via E.
#         If E has been used twice:
#             If there is an unused edge, leave by it.
#             Else if there are no unused edges, leave by a once-used edge.
#             Else if there are no once-used edges, terminate.
#
# If the maze has no solution,
#     you'll find yourself back at the start with all passages marked twice.
#
# .MAZ file format.
#
# A file of 256 bytes, each byte giving the wall positions for a tile
# on a 16 x 16 maze, starting in the top left-hand corner.  The walls
# are encoded in the lower four bits of each byte: TOP = 1, RIGHT = 2,
# DOWN = 4, and LEFT = 8.
#
"""@package docstring
Run a wall follower, flood fill, A*, or Tremaux algorithm on selected mazes.

This is the long usage message placeholder.
"""

# Imports
import cairo
import copy
import getopt
import glib
import gobject
import gtk
import logging
import math
import os
import pango
import pangocairo
import sys
import time
import Queue

# Global constants.
OK = 1
NK = 0
FAILED = -1

VERSION = "0.2"     # Version number.
VERSION_ID = "Version 0.2 of 1 September 2011"
BDSIZE = 512 + 4    # The initial board edge length in pixels.
TILES = 256         # The number of tiles (SIDE ^ 2).
SIDE = 16           # The number of tiles on a side (hardwired).
START = 240         # The id of the starting tile.
TARGET = 119        # The id of the target tile.
INVALID = 256       # The id of an invalid tile.
MILLI = 200         # The update interval in milliseconds.

# Tile state values, greater than the maximum tile index.
MARKED = 512
VISITED = 1024
# Edges used.
UP_WALL = 2048
UP_ONE = 4096
UP_TWO = 8192
RT_WALL = 16384
RT_ONE = 32768
RT_TWO = 65536
DN_WALL = 131072
DN_ONE = 262144
DN_TWO = 524288
LT_WALL = 1048576
LT_ONE = 2097152
LT_TWO = 4194304
NULL = 8388608

# Mouse colors.
(BAD, BGND, WHITE, RED, YELLOW, GREEN, BLUE, BLACK) = (0, 1, 2, 3, 4, 5, 6, 7)
Colors = (BAD, BGND, WHITE, RED, YELLOW, GREEN, BLUE, BLACK)
# RGB triplets indexed by Colors.
# (0.66, 0.66, 0.66), # Grey
RGB = (
    (0.0, 0.0, 0.0), # Bad
    (1.0, 0.0, 0.0), # Bgnd
    (1.0, 1.0, 1.0), # White
    (1.0, 0.0, 0.0), # Red
    (1.0, 1.0, 0.0), # Yellow
    (0.0, 1.0, 0.0), # Green
    (0.0, 0.0, 1.0), # Blue
    (0.0, 0.0, 0.0)  # Black
    )

# Maze directions; used to index into Directions.
(BAD, UP, RIGHT, DOWN, LEFT) = (0, 1, 2, 4, 8)
Directions = ("BAD", "UP", "RIGHT", " ", "DOWN", " ", " ", " ", "LEFT")

# Algorithm ids and names.
(BAD, WF, FF, AS, TR) = (0, 1, 2, 3, 4)
Algonames = ("BAD", "WF", "FF", "AS", "TR")

Dirn = UP           # The current mouse direction.
Targetdirn = BAD    # The mouse direction at the target tile.
Curid = START       # The current mouse position.
Curstep = 0         # The current step in the solution.
Ticks = 0           # Timer tick count.
Timer = None        # Timer instance.
Log = None          # Logger instance.
Flags = {}          # Program flags.
Path = "/usr/local/data/Mazes"

# Help text.
Help = [
    "Mazes, a maze-solving program for MicroMouse mazes\n",
    "title",
    VERSION_ID + ", written by C W Rose.\n",
    "header",
    "Introduction\n",
    "subheader",
    "The Mazes program solves 16 x 16 mazes built in the standard "
    "format used by the MicroMouse competition. Four algorithms "
    "are built in, the Wall Follower, Flood Fill, A* and Tremaux "
    "algorithms, representative samples of maze-solving techniques. "
    "Note that the Wall Follower algorithm generally can't solve "
    "MicroMouse mazes.\n",
    "para",
    "There are also three mazes built in: MicroMouse mazes from the "
    "1985 and 1986 competitions, and a simple maze for testing called "
    "Local. Additional maze files, in MicroMouse MAZ format, can "
    "be loaded into the Local maze slot. (The MAZ format is 256 bytes "
    "of binary data, with the lower four bits of each byte representing "
    "the UP, RIGHT, DOWN, and LEFT maze walls.)\n",
    "para",
    "An associated program called convert.py can convert files between "
    "ASCII and MAZ formats. It can read a file in one of two ASCII formats "
    "(local and MicroMouse) and write out a MAZ file, or read a MAZ file "
    "and write it out in the local ASCII format. For examples of these "
    "formats see the files in the Mazes subdirectory.\n",
    "para",
    "Usage\n",
    "subheader",
    "Select an algorithm from the upper set of radio buttons, and "
    "a maze from the lower set of radio buttons, and click Start. "
    "The program will run until a solution is found, or until it "
    "is paused with the Pause button. To select a new algorithm "
    "or a new maze change the radio button settings and click on "
    "Start. The 'Full flood' checkbox, below the 'Flood Fill' radio "
    "button, allows the Flood Fill algorithm to run until it has "
    "returned to the start point, as a check on maze coverage.\n",
    "para",
    "The 'File Chooser' button, below the list of mazes, can be "
    "used to load a MAZ file. The Chooser listing can be filtered "
    "to display only those files whose names end in .maz or .bin; "
    "this filter is on by default. Once the new maze file has been "
    "loaded it can be selected via the 'Local' radio button. There "
    "isn't a way to unload a MAZ file and revert to the built in "
    "local maze.\n",
    "para",
    "The 'SVG output' checkbox causes solutions to be written out "
    "in DOT file and SVG file format. The initial format is that "
    "of a DOT file, as used by the Graphviz/dotty utility, but if "
    "the dot program is present the .dot file will be automatically "
    "converted to SVG. The default filenames are svgfile.dot and "
    "svgfile.svg. (For further information on names see the section "
    "below which deals with command line arguments.)\n",
    "para",
    "Results\n",
    "subheader",
    "While a solution is still being searched for the mouse is green, "
    "but if a solution to a maze is found the path is highlighted "
    "in blue, and three values are displayed on the right-hand pane. "
    "The first value is the number of maze tiles visited, the second "
    "value is the number of tiles in the final path, and the third "
    "value is the number of steps needed to find the solution.\n",
    "para",
    "In addition, each algorithm shows some specific values on the "
    "maze tiles themselves, and on the mouse. The Wall Follower and "
    "Flood Fill algorithms show the ID of the tile on the maze "
    "background, and, once a solution has been found, the tile sequence "
    "number on the mouse. These algorithms also set the mouse "
    "to yellow on filled paths. The A* algorithm shows the tile's "
    "heuristic value on the maze background, and the tile cost on the "
    "mouse; once a solution has been found, the mouse displays the sum of "
    "the cost, measured from the target, and the heuristic. The Tremaux "
    "algorithm shows the number of times a tile has been visited on the "
    "maze background, and once a solution has been found, the tile sequence "
    "number on the mouse.\n",
    "para",
    "Command line arguments\n",
    "subheader",
    "The Mazes program is usually run from a GUI, but it can also "
    "be run from the command line. In that case there are several "
    "arguments which can be used to control its behaviour; the "
    "--help argument gives a complete list. The arguments are:\n",
    "para",
    "    -a, --auto ALG    Run in auto, algorithm WF|FF|AS|TR", "fixed",
    "    -d, --debug       Set the debugging flag", "fixed",
    "    -h, --help        Show this message and exit", "fixed",
    "    -L, --log FILE    Log messages to the log FILE", "fixed",
    "    -m, --maz FILE    Load the 'local' maze from the .maz FILE", "fixed",
    "    -p, --path PATH   Set the default PATH to the .maz files directory", "fixed",
    "    -s, --svg FILE    Write the solution to the dot/SVG FILE", "fixed",
    "    -v, --verbose     Set the verbose flag", "fixed",
    "    -V, --version     Show the version number\n", "fixed",
    "Most of these flags are straightforward, but the -a flag needs "
    "explaining. It is used to run the program entirely from the "
    "command line, typically from a shell script with a series of "
    "mazes.  If the --verbose flag is added to the command line the "
    "results of each run will be written to standard output. Under "
    "Unix, for example, given a group of .maz files we can use:\n",
    "para",
    "    for i in *maz ; do mazes.py -v -a ff -m $i >> mazes.dat ; done\n",
    "nowrap",
    "to get the results of running the Flood Fill algorithm on every "
    "maze with no further intervention.\n",
    "para",
    "C W Rose - 1 September 2011\n",
    "para",
    "$Revision: 49f619f8a21a $\n",
    "para"
    ]

# Maze program icon data in pixmap format.
Icon = ( ""
    "GdkP"
    "\0\0\14\30"
    "\1\1\0\1"
    "\0\0\0`"
    "\0\0\0\40"
    "\0\0\0\40"
    "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
    "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
    "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
    "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
    "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
    "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\377\0\0\377"
    "\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377"
    "\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377"
    "\377\0\377\377\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377"
    "\0\0\377\0\0\0\0\0\0\0\0\0\0\0\0\0\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\0\0"
    "\0\0\0\0\0\0\0\0\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\0\0\0\0\0\0\0\0\0\0"
    "\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\377\0\377\377\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\0\0\0\0\0\0\0\0\0\0\0\0\377\0\0\377"
    "\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377"
    "\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377"
    "\377\0\377\377\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377"
    "\0\0\377\0\0\0\0\0\0\0\0\0\0\0\0\0\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\0\0"
    "\0\0\0\0\0\0\0\0\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\0\0\0\0\0\0\0\0\0\0"
    "\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\377\0\377\377\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\0\0\0\0\0\0\0\0\0\0\0\0\377\377\0\377"
    "\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377"
    "\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377"
    "\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377"
    "\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\0\0\0\0\0\0"
    "\0\0\0\0\0\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377"
    "\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377"
    "\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377"
    "\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377"
    "\0\377\377\0\0\0\0\0\0\0\0\0\0\0\0\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\0\0"
    "\0\0\0\0\0\0\0\0\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0\377\0\0\0\333\0"
    "\0\333\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\0\0\0\0\0\0\0\0\0\0"
    "\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\377\0\377\377\0\377\0\0\377\0\0\0\333\0\0\333\0\0\333\0\0\333\0"
    "\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\0\0\0\0\0\0\0\0\0\0\0\0\377\0\0\377"
    "\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377"
    "\0\377\0\0\0\333\0\0\333\0\0\333\0\0\333\0\0\333\0\0\333\0\377\0\0\377"
    "\377\0\377\377\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377"
    "\0\0\377\0\0\0\0\0\0\0\0\0\0\0\0\0\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\0\333\0"
    "\0\333\0\0\333\0\0\333\0\0\333\0\0\333\0\377\0\0\377\377\0\377\377\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\0\0"
    "\0\0\0\0\0\0\0\0\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0\0\333\0\0\333\0"
    "\0\333\0\0\333\0\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\0\0\0\0\0\0\0\0\0\0"
    "\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\377\0\377\377\0\377\0\0\377\0\0\377\0\0\0\333\0\0\333\0\377\0\0"
    "\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\0\0\0\0\0\0\0\0\0\0\0\0\377\0\0\377"
    "\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377"
    "\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377"
    "\377\0\377\377\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377"
    "\0\0\377\0\0\0\0\0\0\0\0\0\0\0\0\0\0\377\377\0\377\377\0\377\377\0\377"
    "\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377"
    "\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377"
    "\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377"
    "\377\0\377\377\0\377\377\0\377\377\0\0\0\0\0\0\0\0\0\0\0\0\0\377\377"
    "\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377"
    "\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377"
    "\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377"
    "\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\377\377\0\0\0\0"
    "\0\0\0\0\0\0\0\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377"
    "\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0\377\0\0\377\0\0\377"
    "\0\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0\377"
    "\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377"
    "\377\0\377\377\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377"
    "\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0\377\0\0\377\0\0\377"
    "\0\0\377\0\0\377\0\0\377\0\0\0\0\0\0\0\0\0\0\0\0\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377"
    "\377\0\377\377\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377"
    "\0\0\377\0\0\0\0\0\0\0\0\0\0\0\0\0\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\0\0"
    "\0\0\0\0\0\0\0\0\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\0\0\0\0\0\0\0\0\0\0"
    "\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\377\0\377\377\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\0\0\0\0\0\0\0\0\0\0\0\0\377\0\0\377"
    "\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377"
    "\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377"
    "\377\0\377\377\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377"
    "\0\0\377\0\0\0\0\0\0\0\0\0\0\0\0\0\0\377\0\0\377\0\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377\0\377\0\0\377\0\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\377\0\377\377\0"
    "\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\377\0\0\0\0"
    "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
    "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
    "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
    "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
    "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
    "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
    )

#
# Classes.
#

#
# Class Tile
#
# Graph node and adjacent edges.
#
class Tile(object):
    """ Docstring placeholder.
    """
    #
    # T i l e . _ _ i n i t _ _
    #
    # Class Tile - initialise a Tile.
    #
    # Returns:  Nothing     Always
    #
    def __init__(self, c, g, h, i, m, o, p, s, v):
        # NB. the name self.id leads to infinite recursion.
        self._c = c # on closed list
        self._g = g # g factor
        self._h = h # h factor
        self._i = i # tile id
        self._m = m # on marked path
        self._o = o # on open list
        self._p = p # parent id
        self._s = s # tile state
        self._v = v # tile visibility
        return

    #
    def __str__(self):
        #return str.format("I {0:3} C {1:5} G {2:3} H {3:3} O {1:5} P {4:3}",
        #    self.id, str(self._c), self._g, self._h, str(self._o), self._p)
        return "I %3d C %-5s G %3d H %3d M %-5s O %-5s P %3d S%6d V%d" % \
            (self._i, self._c, self._g, self._h, self._m, self._o, \
            self._p, self._s, self._v)

    #
    def __cmp__(self, other):
        return cmp((self._g + self._h * 10), (other._g + other._h * 10))

    #
    # Getters and setters.
    #
    def isclosed(self):
        return self._c
    def setclosed(self, c):
        self._c = c
    closed = property(isclosed, setclosed)
    #
    def getcost(self):
        return self._g
    def setcost(self, g):
        self._g = g
    cost = property(getcost, setcost)
    #
    def getheuristic(self):
        return self._h
    def setheuristic(self, h):
        self._h = h
    heuristic = property(getheuristic, setheuristic)
    #
    def getid(self):
        return self._i
    def setid(self, i):
        self._i = i
    id = property(getid, setid)
    #
    def ismarked(self):
        return self._m
    def setmarked(self, m):
        self._m = m
    marked = property(ismarked, setmarked)
    #
    def isopen(self):
        return self._o
    def setopen(self, o):
        self._o = o
    open = property(isopen, setopen)
    #
    def getparent(self):
        return self._p
    def setparent(self, p):
        self._p = p
    parent = property(getparent, setparent)
    #
    def getstate(self):
        return self._s
    def setstate(self, s):
        self._s = s
    state = property(getstate, setstate)
    #
    def getvisible(self):
        return self._v
    def setvisible(self, v):
        self._v = v
    visible = property(getvisible, setvisible)

#
# Class Board
#
# Drawing board class.
#
class Board(gtk.DrawingArea):
    """Docstring placeholder.
    """
    __gsignals__ = {"expose_event": "override"}

    #
    # Data
    #
    # Maze names, which must match the plans.
    mazenames = ["Mouse 85us", "Mouse 86us", "Local"]
    #
    # Maze plans.
    mazeplans = [
        # Micromouse maze, USA 1985
        #
        # 0 1 2 3 4 5 6 7 8 9 101112131415
       [" _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ ",  # -1
        "|  _ _ _ _ _ _ _ _ _ _ _ _ _ _  |",  #  0
        "| |  _ _ _ _     _ _ _ _ _ _  | |",  #  1
        "| | |  _ _  | |  _ _   _ _  | | |",  #  2
        "| | | |   | | | |_ _ _ _  | |  _|",  #  3
        "| | | | | | | |_ _ _ _   _| | | |",  #  4
        "| | | | | | | |  _ _  |_ _  | | |",  #  5
        "| | | | | | |  _|    _ _  |_ _| |",  #  6
        "| | | | | | | |   | |   | |_   _|",  #  7
        "| |_ _ _| | | |_ _| | | |_  |_  |",  #  8
        "| |    _| | |_ _ _ _|_ _  | |  _|",  #  9
        "| | |_ _ _| |  _ _   _   _| |_  |",  # 10
        "| |   |  _ _|_ _ _ _   _   _   _|",  # 11
        "|_  |  _|  _ _ _ _  |_   _   _  |",  # 12
        "|   | |  _|  _ _  |_  |_   _   _|",  # 13
        "| | |  _|_ _  |  _ _|_  |_ _ _  |",  # 14
        "|_|_ _ _ _ _ _|_ _ _ _ _ _ _ _ _|",  # 15
       ],
        # Micromouse maze, USA 1986
        #
        # 0 1 2 3 4 5 6 7 8 9 101112131415
       [" _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ ",  # -1
        "|  _ _ _ _ _ _   _      |       |",  #  0
        "| |_        | | |_  | | |_| | | |",  #  1
        "| | | | | | | | |_ _|_|  _ _|_| |",  #  2
        "| | | | | | | |  _ _ _   _ _  | |",  #  3
        "| |   | | | | | |_ _ _   _ _  | |",  #  4
        "| | | |       | |  _ _   _ _  | |",  #  5
        "| |_| | | | | |_|_ _ _ _ _ _ _| |",  #  6
        "|  _    | | | |   |_ _ _ _ _  | |",  #  7
        "| | | | | | | |  _|_ _ _ _ _ _  |",  #  8
        "| | | | | | | |  _ _ _   _ _  | |",  #  9
        "| | | |       | |_ _ _   _ _  | |",  # 10
        "| |   | | | | | |_ _ _   _ _    |",  # 11
        "| | | | | | |   |  _ _   _ _ _| |",  # 12
        "| |_| | | | | |    _| |  _  | | |",  # 13
        "| |  _ _ _ _ _|_|_ _| |_| | | | |",  # 14
        "|_|_ _ _ _ _ _ _ _ _ _ _ _ _ _ _|",  # 15
       ],
        # Trivial maze for algorithm debugging.
        #
        # 0 1 2 3 4 5 6 7 8 9 101112131415
       [" _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ ", # -1
        "| |_ _ _ _ _ _ _ _ _ _ _ _ _ _ _|", #  0
        "| |_ _ _ _ _ _ _ _ _ _ _ _ _ _ _|", #  1
        "| |_ _ _ _ _ _ _ _ _ _ _ _ _ _ _|", #  2
        "| |_ _ _ _ _ _ _ _ _ _ _ _ _ _ _|", #  3
        "| |_ _ _ _ _ _ _ _ _ _ _ _ _ _ _|", #  4
        "| |_ _ _ _ _ _ _ _ _ _ _ _ _ _ _|", #  5
        "| |_ _ _ _ _ _ _ _ _ _ _ _ _ _ _|", #  6
        "| |_ _ _   _ _ _ _ _ _ _ _ _ _ _|", #  7
        "| |  _ _| |_ _ _ _   _ _ _ _ _ _|", #  8
        "| |_ _ _ _ _ _ _ _ _ _ _   _ _ _|", #  9
        "| |_ _ _ _ _ _ _ _ _ _ _| |_ _ _|", # 10
        "|  _ _ _ _ _ _ _ _ _ _ _ _ _ _ _|", # 11
        "| |_ _ _ _ _ _ _ _ _ _ _ _ _ _ _|", # 12
        "| |_ _ _ _ _ _ _ _ _ _ _ _ _ _ _|", # 13
        "| |_ _ _ _ _ _ _ _ _ _ _ _ _ _ _|", # 14
        "|_|_ _ _ _ _ _ _ _ _ _ _ _ _ _ _|", # 15
        ]]
    #
    # Maze tile distance heuristics (Manhattan distances).
    distances = [
       [14, 13, 12, 11, 10,  9,  8,  7,   8,  9, 10, 11, 12, 13, 14, 15,
        13, 12, 11, 10,  9,  8,  7,  6,   7,  8,  9, 10, 11, 12, 13, 14,
        12, 11, 10,  9,  8,  7,  6,  5,   6,  7,  8,  9, 10, 11, 12, 13,
        11, 10,  9,  8,  7,  6,  5,  4,   5,  6,  7,  8,  9, 10, 11, 12,
        10,  9,  8,  7,  6,  5,  4,  3,   4,  5,  6,  7,  8,  9, 10, 11,
         9,  8,  7,  6,  5,  4,  3,  2,   3,  4,  5,  6,  7,  8,  9, 10,
         8,  7,  6,  5,  4,  3,  2,  1,   2,  3,  4,  5,  6,  7,  8,  9,
         7,  6,  5,  4,  3,  2,  1,  0,   1,  2,  3,  4,  5,  6,  7,  8,

         8,  7,  6,  5,  4,  3,  2,  1,   2,  3,  4,  5,  6,  7,  8,  9,
         9,  8,  7,  6,  5,  4,  3,  2,   3,  4,  5,  6,  7,  8,  9, 10,
        10,  9,  8,  7,  6,  5,  4,  3,   4,  5,  6,  7,  8,  9, 10, 11,
        11, 10,  9,  8,  7,  6,  5,  4,   5,  6,  7,  8,  9, 10, 11, 12,
        12, 11, 10,  9,  8,  7,  6,  5,   6,  7,  8,  9, 10, 11, 12, 13,
        13, 12, 11, 10,  9,  8,  7,  6,   7,  8,  9, 10, 11, 12, 13, 14,
        14, 13, 12, 11, 10,  9,  8,  7,   8,  9, 10, 11, 12, 13, 14, 15,
        15, 14, 13, 12, 11, 10,  9,  8,   9, 10, 11, 12, 13, 14, 15, 16
       ],
        #
       [
        14, 13, 12, 11, 10,  9,  8,  7,   7,  8,  9, 10, 11, 12, 13, 14,
        13, 12, 11, 10,  9,  8,  7,  6,   6,  7,  8,  9, 10, 11, 12, 13,
        12, 11, 10,  9,  8,  7,  6,  5,   5,  6,  7,  8,  9, 10, 11, 12,
        11, 10,  9,  8,  7,  6,  5,  4,   4,  5,  6,  7,  8,  9, 10, 11,
        10,  9,  8,  7,  6,  5,  4,  3,   3,  4,  5,  6,  7,  8,  9, 10,
         9,  8,  7,  6,  5,  4,  3,  2,   2,  3,  4,  5,  6,  7,  8,  9,
         8,  7,  6,  5,  4,  3,  2,  1,   1,  2,  3,  4,  5,  6,  7,  8,
         7,  6,  5,  4,  3,  2,  1,  0,   0,  1,  2,  3,  4,  5,  6,  7,

         7,  6,  5,  4,  3,  2,  1,  0,   0,  1,  2,  3,  4,  5,  6,  7,
         8,  7,  6,  5,  4,  3,  2,  1,   1,  2,  3,  4,  5,  6,  7,  8,
         9,  8,  7,  6,  5,  4,  3,  2,   2,  3,  4,  5,  6,  7,  8,  9,
        10,  9,  8,  7,  6,  5,  4,  3,   3,  4,  5,  6,  7,  8,  9, 10,
        11, 10,  9,  8,  7,  6,  5,  4,   4,  5,  6,  7,  8,  9, 10, 11,
        12, 11, 10,  9,  8,  7,  6,  5,   5,  6,  7,  8,  9, 10, 11, 12,
        13, 12, 11, 10,  9,  8,  7,  6,   6,  7,  8,  9, 10, 11, 12, 13,
        14, 13, 12, 11, 10,  9,  8,  7,   7,  8,  9, 10, 11, 12, 13, 14
       ]]
    #
    # Ordered list of all maze tiles.
    tiles = []

    #
    # Class functions.
    #

    #
    # B o a r d . _ _ i n i t _ _
    #
    # Class Board - initialise a Board.
    #
    # Returns:  Nothing     Always
    #
    def __init__(self, frame):
        """ Docstring placeholder.
        """
        global Flags

        if Flags["dbg"]:
            print "Board.__init__() mazeid %d" % frame.mazeid
        gtk.DrawingArea.__init__(self)
        self.set_size_request(BDSIZE, BDSIZE)
        self.frame = frame
        self.mazeid = frame.mazeid
        self.algo = frame.algo
        self.context = None
        self.pcontext = None
        self.maze = [0 for j in range(TILES)]
        self.steps = [0 for j in range(TILES)]
        self.build_board()
        self.width  = 0
        self.height = 0
        self.xloc = 0
        self.yloc = 0
        self.tiles = []     # ### del can delete only 128 items ???
        for j in range(TILES):
            c = False
            g = 0
            h = 0
            m = False
            o = False
            p = 0
            s = 0
            v = 0
            self.tiles.append(Tile(c, g, h, j, m, o, p, s, v))

        # Open list (priority queue) used by A* algorithm.
        self.queue = None

        return

    #
    # d o _ e x p o s e _ e v e n t
    #
    # Class Board - expose event handler.
    #
    # Returns:  Nothing     Always
    #
    def do_expose_event(self, event):
        """ Docstring placeholder.
        """
        global Flags

        if Flags["dbg"]:
            print "Board.do_expose_event()"
        context = self.window.cairo_create()
        pcontext = pangocairo.CairoContext(context)
        context.rectangle(event.area.x, event.area.y,
            event.area.width, event.area.height)
        context.clip()
        # These updates aren't always correct.
        self.context = context
        self.pcontext = pcontext
        self.height, self.width = self.window.get_size()
        self.draw(self.context, self.pcontext, *self.window.get_size())

        return

    #
    # b u i l d _ b o a r d
    #
    # Class Board - build a board.
    #
    # Returns:  True    Success
    #           False   Otherwise
    #
    def build_board(self):
        """ Docstring placeholder.
        """
        global Flags

        if self.mazeid == 2 and Flags["maz"]:
            if not self.load_maze(self.maze):
                s, t, u = Flags["mazfile"].rpartition("/")
                self.frame.win.set_title("Could not load maze file " + u)
                Flags["maz"] = False
                #self.frame.win.set_title("Maze is " + self.mazenames[self.mazeid])
                #self.build_maze(self.mazeplans[self.mazeid], self.maze)
                return False
        else:
            self.build_maze(self.mazeplans[self.mazeid], self.maze)
            # steps are used only by the Tremaux algorithm.
            self.steps = [0 for j in range(TILES)]

        return True

    #
    # b u i l d _ m a z e
    #
    # Class Board - build a maze from an ASCII layout.
    #
    # Returns:  Nothing     Always
    #
    def build_maze(self, plan, newmaze):
        """ Docstring placeholder.
        """
        maze = [0 for j in range(17 * 16)]
        index = 0
        for line in plan:
            # Update the map array
            for j in range(17):
                # Get the left-hand edge.
                if j == 0:
                    v = 0
                    c = line[j]
                    if c == "|":
                        v |= LEFT
                # Tiles are described by pairs of characters.
                else:
                    c = line[j * 2 - 1]
                    d = line[j * 2]
                    if c == "_":
                        v |= DOWN
                    if d == "|":
                        v |= RIGHT
                    if index > 0 and (maze[index - 1] & RIGHT):
                        v |= LEFT
                    if index > 15 and (maze[index - 16] & DOWN):
                        v |= UP
                    maze[index] = v
                    v = 0
                    index += 1

        # Used for debugging only.
        if False:
            for k in range(TILES):
                if maze[k + 16] != self.maze[k]:
                    print "Mismatch at index", k

        for j in range(TILES):
            newmaze[j] = maze[j + 16]

        return

    #
    # c h e c k _ m o v e
    #
    # Class Board - check for a valid mouse move.
    #
    # Returns:  True    Valid move
    #           False   Invalid move
    #
    def check_move(self, ident, dirn):
        """ Docstring placeholder.
        """
        global Flags

        if dirn & self.maze[ident]:
            if Flags["dbg"]:
                print "In Board.check_move(): tile %d has bad direction %s" % (ident, Directions[dirn])
            return False
        else:
            return True

    #
    # d r a w
    #
    # Class Board - draw a board's grid, maze and cursor.
    #
    # Returns:  Nothing     Always
    #
    def draw(self, context, pcontext, width, height):
        """ Docstring placeholder.
        """
        global Flags

        if Flags["dbg"]:
            print "Board.draw()"
        # Needed to keep these values current ???
        self.height = height
        self.width = width
        self.context = context
        self.pcontext = pcontext

        # Inital setup.
        context.set_line_width(4)

        # Reduce the time taken by calls to getvisible()
        visible = [0 for j in range(TILES)]
        for j in range(TILES):
            visible[j] = self.tiles[j].getvisible()

        # Draw the background.
        context.set_source_rgb(*RGB[BGND])
        context.rectangle(0, 0, width, height)
        context.fill_preserve()

        # Draw the grid.
        context.set_source_rgb(*RGB[YELLOW])
        xincr = (width - 4) / 16
        yincr = (height - 4) / 16
        for t in range(2 + xincr, width - xincr, xincr):
            context.move_to(t, 4)
            context.line_to(t, yincr * 16)
        for u in range(2 + yincr, height - yincr, yincr):
            context.move_to(4, u)
            context.line_to(xincr * 16, u)
        # This gives an all-black grid.
        # context.stroke_preserve()
        context.stroke()

        # Draw the maze; only the right/down lines need drawing.
        context.set_source_rgb(*RGB[BLACK])
        for j in range(TILES):
            if self.maze[j] & UP:
                pass
            if self.maze[j] & RIGHT:
                t = (j % 16 + 1) * xincr + 2
                u = (j / 16) * yincr + 2
                context.move_to(t, u - 2)
                context.line_to(t, u + yincr + 2)
            if self.maze[j] & DOWN:
                t = (j % 16) * xincr + 2
                u = (j / 16 + 1) * yincr + 2
                context.move_to(t - 2, u)
                context.line_to(t + xincr + 2, u)
            if self.maze[j] & LEFT:
                pass
        context.stroke()

        # Draw the bounding rectangle.
        context.set_source_rgb(*RGB[BLACK])
        context.rectangle(2, 2, xincr * 16, yincr * 16)
        context.stroke()

        # Add a relevant tile value.
        context.set_source_rgb(*RGB[YELLOW])
        # Slant NORMAL, weight NORMAL
        context.select_font_face("sans-serif",
            cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
        context.set_font_size(10.0)
        font = pango.FontDescription("sans-serif 10")
        layout = pcontext.create_layout()
        layout.set_font_description(font)
        #metrics = pcontext.get_metrics("sans-serif, 10")
        #cwidth = pango.PIXELS(metrics.get_approximate_char_width())
        j = 0
        for u in range(yincr / 2, height - yincr / 2, yincr):
            for t in range(xincr / 2, width - xincr / 2, xincr):
                # Clear the tile where necessary.
                if visible[j] == BGND:
                    self.show_mouse(j, visible[j], False, None, 0)
                    self.tiles[j].setvisible(0)
                    visible[j] = 0
                # Show the relevant text.
                if self.algo == WF:
                    val = j
                elif self.algo == FF:
                    val = j
                elif self.algo == AS:
                    val = self.tiles[j].getheuristic()
                elif self.algo == TR:
                    val = self.tiles[j].getcost()
                else:
                    val = 0
                layout.set_text(str(val))
                w, h = layout.get_size()
                # One pixel = pango.SCALE device units.
                w = w / pango.SCALE
                h = h / pango.SCALE
                #context.move_to(t - xincr / 2 + 2 + (xincr - w) / 2, u - yincr / 2 + 2 + (yincr - h) / 2)
                # Simplified calculation.
                context.move_to(t + 2 - w / 2, u + 2 - h / 2)
                pcontext.update_layout(layout)
                pcontext.show_layout(layout)
                j = j + 1
        context.stroke()

        # Test mouse drawing.
        #self.show_mouse(3, BLUE, False, None, 0)
        #self.show_mouse(249, BLUE, False, None, 0)

        # Update the display for each visible tile.
        for j in range(TILES):
            if visible[j] != 0:
                if self.algo == WF:
                    val = self.tiles[START].getcost() - self.tiles[j].getcost()
                    self.show_mouse(j, visible[j], True, layout, val)
                elif self.algo == FF:
                    val = self.tiles[START].getcost() - self.tiles[j].getcost()
                    self.show_mouse(j, visible[j], True, layout, val)
                elif self.algo == AS:
                    val = self.tiles[j].getcost() + self.tiles[j].getheuristic()
                    # At the moment, approximations are all multiples of ten.
                    if visible[j] == GREEN:
                        val = val / 10
                    self.show_mouse(j, visible[j], True, layout, val)
                elif self.algo == TR:
                    # These values are shown only on the final path.
                    val = self.tiles[START].getcost() - self.tiles[j].getcost()
                    self.show_mouse(j, visible[j], True, layout, val)

        return

    #
    # d u m p c l o s e d
    #
    # Class Board - run this function exactly once.
    #
    # Returns:  Nothing     Always
    #
    def dumpclosed(self, count=[0]):
        """ Docstring placeholder.
        """
        count[0] += 1
        if  count[0] == 1:
            for j in range(TILES):
                print "%d %s" % (j, self.tiles[j].isclosed())

        return

    #
    # l o a d _ m a z e
    #
    # Class Board - load a maze from a .maz file.
    #
    # Returns:  True    Success
    #           False   Otherwise
    #
    def load_maze(self, maze):
        """ Docstring placeholder.
        """
        global Flags

        try:
            try:
                mazfp = open(Flags["mazfile"], 'r')
            except IOError, err:
                raise Usage(err)
            try:
                f = os.stat(Flags["mazfile"])
                if f.st_size != 256:
                    raise Usage(".maz file %s should be 256 bytes long" % Flags["mazfile"])
            except OSError, err:
                raise Usage("Cannot understand .maz file %s" % Flags["mazfile"])
            try:
                newmaze = mazfp.read(256)
                for j in range(256):
                    maze[j] = ord(newmaze[j])
            except OSError, err:
                raise Usage(err)
            mazfp.close()

        except Usage, err:
            print >> sys.stderr, err.msg
            print >> sys.stderr, "for help use --help"
            return False

        return True

    #
    # s e t _ m o u s e _ c o l o r
    #
    # Class Board - set a tile's mouse color.
    #
    # Returns:  Nothing     Always
    #
    def set_mouse_color(self, ident, color):
        """ Docstring placeholder.
        """
        global Flags

        if Flags["dbg"]:
            print "Board.set_mouse_color() ident %d color %d" % (ident, color)
        if not color in Colors:
            self.tiles[ident].setvisible(0)
        else:
            self.tiles[ident].setvisible(color)
        self.queue_draw()
        return

    #
    # s h o w _ m o u s e
    #
    # Class Board - show or clear the mouse.
    #
    # Returns:  Nothing     Always
    #
    # The layout and value arguments are valid only when
    # the mouse is to be labelled (flg is True).
    #
    def show_mouse(self, ident, clr, flg, layout, value):
        """ Docstring placeholder.
        """
        global Flags

        if Flags["dbg"]:
            print "Board.show_mouse() ident %d flg %s" % (ident, str(flg))

        xincr = (self.width - 4) / 16
        yincr = (self.height - 4) / 16
        if ident == 0:
            xloc = 0
            yloc = 0
        else:
            xloc = (ident % 16) * xincr
            yloc = (ident / 16) * yincr
        # Allow for rectangular boards.
        if xincr < yincr:
            radius = xincr / 2 - 4
        else:
            radius = yincr / 2 - 4
        context = self.context
        pcontext = self.pcontext
        context.save()
        context.set_source_rgb(*RGB[clr])
        t = xloc + xincr / 2.0
        u = yloc + yincr / 2.0
        context.translate(t + 2, u + 2)
        context.scale(xincr / 2.0 + 2.0, yincr / 2.0 + 2.0)
        context.arc(0, 0, 0.7, 0, 2 * math.pi)
        context.fill()
        context.stroke()
        context.restore()
        # The Wall Follower, Flood Fill and Tremaux algorithms use labels only on the final path.
        if (self.algo == WF or self.algo == FF or self.algo == TR) and clr != BLUE:
            return
        if flg:
            # We need to label the mouse.
            if clr == BLUE:
                context.set_source_rgb(*RGB[WHITE])
            else:
                context.set_source_rgb(*RGB[BLACK])
            # Add a relevant tile value.
            layout.set_text(str(value))
            w, h = layout.get_size()
            w = w / pango.SCALE
            h = h / pango.SCALE
            #context.move_to(t - xincr / 2 + 2 + (xincr - w) / 2, u - yincr / 2 + 2 + (yincr - h) / 2)
            # Simplified calculation.
            context.move_to(t + 2 - w / 2, u + 2 - h / 2)
            pcontext.update_layout(layout)
            pcontext.show_layout(layout)

        return


#
# Class Frame
#
# Window frame class.
#
class Frame(object):
    """ Docstring placeholder.
    """
    #
    # F r a m e . _ _ i n i t _ _
    #
    # Class Frame - initialise a Frame.
    #
    # Returns:  Nothing     Always
    #
    def __init__(self, win, a, m):
        """ Docstring placeholder.
        """
        global Flags

        if Flags["dbg"]:
            print "Frame.__init__()"
        #win = gtk.Window()
        self.win = win
        self.algo = a
        self.mazeid = m
        self.board = Board(self)
        # Sub-boxes.
        hbox = gtk.HBox()
        vbox = gtk.VBox()
        #vbox.set_spacing(0)
        # Half-height vertical spacers.
        spacer_1 = gtk.Label(" ")
        spacer_1.modify_font(pango.FontDescription("sans 6"))
        spacer_2 = gtk.Label(" ")
        spacer_2.modify_font(pango.FontDescription("sans 6"))
        spacer_3 = gtk.Label(" ")
        spacer_3.modify_font(pango.FontDescription("sans 6"))
        # Version ID.
        #header_v = gtk.Label(VERSION_ID)
        #header_v.set_alignment(0.1, 1.0)
        # Help text window.
        button_h = gtk.Button("Help")
        button_h.connect("clicked", self.on_clicked_help, win)
        # Algorithm selection.
        header_a = gtk.Label("  Algorithms  ")
        radio_a = gtk.RadioButton(None, "Wall Follower  ", False)
        radio_b = gtk.RadioButton(radio_a, "Flood Fill", False)
        radio_c = gtk.RadioButton(radio_a, "A*", False)
        radio_d = gtk.RadioButton(radio_a, "Tremaux", False)
        radios = (radio_a, radio_b, radio_c, radio_d)
        # Zero is BAD
        radios[self.algo - 1].set_active(True)
        radio_a.connect("clicked", self.on_toggled, 1)
        radio_b.connect("clicked", self.on_toggled, 2 )
        radio_c.connect("clicked", self.on_toggled, 3)
        radio_d.connect("clicked", self.on_toggled, 4)
        check_a = gtk.CheckButton("Full flood")
        check_a.connect("clicked", self.on_checked, 10)
        # Maze selection.
        header_b = gtk.Label("  Mazes       ")
        radio_x = gtk.RadioButton(None, self.board.mazenames[0], False)
        radio_y = gtk.RadioButton(radio_x, self.board.mazenames[1], False)
        radio_z = gtk.RadioButton(radio_x, self.board.mazenames[2], False)
        if Flags["maz"]:
            radio_z.set_active(True)
        radio_x.connect("clicked", self.on_toggled, 5)
        radio_y.connect("clicked", self.on_toggled, 6)
        radio_z.connect("clicked", self.on_toggled, 7)
        # FileChooser button/dialog setup.
        self.filter = gtk.FileFilter()
        self.filter.set_name("bin/maz files")
        self.filter.add_pattern("*.bin")
        self.filter.add_pattern("*.maz")
        self.button_f = gtk.FileChooserButton("Select a .maz file", None)
        self.button_f.set_action(gtk.FILE_CHOOSER_ACTION_OPEN)
        self.button_f.set_width_chars(10)
        self.button_f.add_filter(self.filter)
        self.button_f.set_current_folder(Flags["path"])
        self.button_f.connect("file-set", self.on_file_set)
        check_b = gtk.CheckButton("File filter")
        check_b.set_active(True)
        check_b.connect("clicked", self.on_checked, 11)
        check_c = gtk.CheckButton("SVG output")
        check_c.connect("clicked", self.on_checked, 12)
        if Flags["svg"]:
            check_c.set_active(True)
        # Progress text.
        self.label = gtk.Label("Wait ...")
        # Pause button.
        self.toggle = gtk.ToggleButton("Pause", False)
        self.handler = self.toggle.connect("clicked", self.on_toggled, 8)
        self.toggle.set_sensitive(False)
        # This only works for CheckButton and RadioButton.
        #toggle.set_mode(True)
        # Start button.
        self.button_s = gtk.Button("  Start  ")
        self.button_s.connect("clicked", self.on_clicked_start)
        # Quit button.
        self.button_q = gtk.Button("  Quit  ")
        self.button_q.connect("clicked", self.on_clicked_quit)
        # Widget packing.
        vbox.pack_start(button_h, expand=False)
        vbox.pack_start(spacer_1, expand=False)
        vbox.pack_start(header_a, expand=False)
        vbox.pack_start(radio_a, expand=False)
        vbox.pack_start(radio_b, expand=False)
        vbox.pack_start(check_a, expand=False)
        vbox.pack_start(radio_c, expand=False)
        vbox.pack_start(radio_d, expand=False)
        vbox.pack_start(spacer_2, expand=False)
        vbox.pack_start(header_b, expand=False)
        vbox.pack_start(radio_x, expand=False)
        vbox.pack_start(radio_y, expand=False)
        vbox.pack_start(radio_z, expand=False)
        vbox.pack_start(self.button_f, expand=False)
        vbox.pack_start(check_b, expand=False)
        vbox.pack_start(check_c, expand=False)
        vbox.pack_start(spacer_3, expand=False)
        vbox.pack_start(self.label, expand=False)
        vbox.pack_end(self.button_q, expand=False)
        vbox.pack_end(self.toggle, expand=False)
        vbox.pack_end(self.button_s, expand=False)
        hbox.pack_start(self.board)
        hbox.pack_start(vbox, expand=False)
        win.add(hbox)
        # Increase the default size of the Start/Pause/Quit buttons.
        w, h = self.button_q.size_request()
        self.button_q.set_size_request(int(w), int((w + h) / 2))
        #self.toggle.set_size_request(int(w), int((w + h) / 2))
        self.button_s.set_size_request(int(w), int((w + h) / 2))
        # Set the window title.
        if self.mazeid == 2 and Flags["maz"]:
            s, t, u = Flags["mazfile"].rpartition("/")
            self.win.set_title("Local maze file is " + u)
        else:
            self.win.set_title("Maze is " + self.board.mazenames[self.mazeid])
        self.rsig = None
        self.esig = None

        return

    #
    # o n _ c h e c k e d
    #
    # Class Frame - check button handler.
    #
    # Returns:  Nothing     Always
    #
    def on_checked(self, widget, ident):
        """ Docstring placeholder.
        """
        global Flags

        if ident == 10:
            if widget.get_active():
                Flags["full"] = True
            else:
                Flags["full"] = False
        elif ident == 11:
            if widget.get_active():
                self.button_f.add_filter(self.filter)
            else:
                self.button_f.remove_filter(self.filter)
        elif ident == 12:
            if widget.get_active():
                Flags["svg"] = True
            else:
                Flags["svg"] = False

        return

    #
    # o n _ c l i c k e d _ h e l p
    #
    # Class Frame - help button clicked signal callback.
    #
    # Returns:  Nothing     Always
    #
    def on_clicked_help(self, widget, win):
        """ Docstring placeholder.
        """
        global Help

        window = gtk.Window()
        window.set_title("Mazes Help file")
        window.set_position(gtk.WIN_POS_MOUSE)

        # A textview needs an additional scrolled window.
        scrollwin = gtk.ScrolledWindow()
        scrollwin.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
        textview = gtk.TextView()
        textview.set_editable(False)
        textview.set_cursor_visible(False)
        textview.set_justification(gtk.JUSTIFY_LEFT)
        textview.set_wrap_mode(gtk.WRAP_WORD)
        textview.set_left_margin(10)
        textbuff = textview.get_buffer()
        tagtable = textbuff.get_tag_table()

        # Set textags.
        tt_0 = textbuff.create_tag("title", justification=gtk.JUSTIFY_CENTER,
            weight=pango.WEIGHT_BOLD, size=12 * pango.SCALE)
        tt_1 = textbuff.create_tag("header", justification=gtk.JUSTIFY_CENTER,
            weight=pango.WEIGHT_BOLD, size=10 * pango.SCALE)
        tt_2 = textbuff.create_tag("subheader", weight=pango.WEIGHT_BOLD,
            size=10 * pango.SCALE)
        tt_3 = textbuff.create_tag("para", weight=pango.WEIGHT_NORMAL,
            size=10 * pango.SCALE)
        tt_4 = textbuff.create_tag("fixed", family="monospace",
            weight=pango.WEIGHT_NORMAL, size=10 * pango.SCALE)
        tt_5 = textbuff.create_tag("nowrap", wrap_mode=gtk.WRAP_NONE,
            family="monospace", weight=pango.WEIGHT_NORMAL, size=10 * pango.SCALE)

        # Load text / tag pairs.
        itr = textbuff.get_iter_at_offset(0)
        for j in range(len(Help) /  2):
            textbuff.insert_with_tags_by_name(itr, Help[j * 2], Help[j * 2 + 1])
            textbuff.insert(itr, "\n")

        # Show the window.
        scrollwin.add(textview)
        window.add(scrollwin)
        window.set_size_request(BDSIZE / 2, BDSIZE / 2)
        window.show_all()

        return

    #
    # o n _ c l i c k e d _ s t a r t
    #
    # Class Frame - start button clicked signal callback.
    #
    # Returns:  Nothing     Always
    #
    # Required sequence is __init__(), allocate(), realize(), expose()
    #
    def on_clicked_start(self, widget):
        """ Docstring placeholder.
        """
        global Curid, Curstep, Dirn, Flags, Ticks, Timer

        # Set up for a new run.
        self.setup_run(widget)

        # Initialise the maze algorithm.
        if self.algo == FF:
            self.board.set_mouse_color(START, GREEN)
            self.board.tiles[START].setparent(START)
        if self.algo == AS:
            self.board.queue = Queue.PriorityQueue(0)
            self.board.queue.put(self.board.tiles[Curid])
            self.board.tiles[Curid].setopen(True)

        # Log the new setup.
        if Flags["dbg"]:
            s = "Maze is " + self.board.mazenames[self.mazeid]
            t = time.asctime()
            if self.algo == WF:
                Log.debug("In on_clicked_start(): running Wall Follower algorithm on %s at %s", s, t)
            elif self.algo == FF:
                Log.debug("In on_clicked_start(): running Flood Fill algorithm on %s at %s", s, t)
            elif self.algo == AS:
                Log.debug("In on_clicked_start(): running A* algorithm on %s at %s", s, t)
            elif self.algo == TR:
                Log.debug("In on_clicked_start(): running Tremaux algorithm on %s at %s", s, t)
            else:
                Log.debug("In on_clicked_start(): running unknown algorithm on %s at %s", s, t)

        # Run the timer.
        if self.algo == WF:
            Timer = glib.timeout_add(MILLI, on_timeout_wf, self.board, self.label, self.toggle)
        elif self.algo == FF:
            Timer = glib.timeout_add(MILLI, on_timeout_ff, self.board, self.label, self.toggle)
        elif self.algo == AS:
            Timer = glib.timeout_add(MILLI, on_timeout_as, self.board, self.label, self.toggle)
        elif self.algo == TR:
            Timer = glib.timeout_add(MILLI, on_timeout_tr, self.board, self.label, self.toggle)
        else:
            Timer = None

        return

    #
    # o n _ c l i c k e d _ q u i t
    #
    # Class Frame - quit button clicked signal callback.
    #
    # Returns:  Nothing     Always
    #
    def on_clicked_quit(self, widget):
        """ Docstring placeholder.
        """
        gtk.main_quit()

    #
    # o n _ e x p o s e _ e v e n t
    #
    # Class Frame - expose-event signal callback.
    #
    # Returns:  Nothing     Always
    #
    # All drawing apart from the mouse takes place here.
    #
    def on_expose_event(self, widget, event):
        """ Docstring placeholder.
        """
        print "Frame.on_expose_event()"
        return

    #
    # o n _ f i l e _ s e t
    #
    # Class Frame - FileChooserButton file-set callback.
    #
    # Returns:  Nothing     Always
    #
    def on_file_set(self, widget):
        """ Docstring placeholder.
        """
        global Flags

        if Flags["dbg"]:
            print "Frame.on_file_set()"

        s = widget.get_filename()
        if s != None:
            Flags["maz"] = True
            Flags["mazfile"] = s

        # Set up for a new run.
        if self.mazeid == 2 and Flags["maz"]:
            self.setup_run(widget)

        return

    #
    # o n _ r e a l i z e
    #
    # Class Frame - realize signal callback.
    #
    # Returns:  Nothing     Always
    #
    def on_realize(self, widget):
        """ Docstring placeholder.
        """
        print "Frame.on_realize()"
        return

    #
    # o n _ t o g g l e d
    #
    # Class Frame - button toggled signal callback.
    #
    # Returns:  Nothing     Always
    #
    # Button indices are 1-based.
    #
    def on_toggled(self, widget, ident):
        """ Docstring placeholder.
        """
        global Flags, Timer

        if Flags["dbg"]:
            print "Frame.on_toggled() button %d active" % ident

        # Never happen.
        if ident > 8:
            return

        # Pause button.
        if ident == 8:
            if widget.get_active():
                widget.set_label("Run")
                if Timer != None:
                    glib.source_remove(Timer)
                    Timer = None
            else:
                widget.set_label("Pause")
                if self.algo == WF:
                    Timer = glib.timeout_add(MILLI, on_timeout_wf,
                        self.board, self.label, self.toggle)
                elif self.algo == FF:
                    Timer = glib.timeout_add(MILLI, on_timeout_ff,
                        self.board, self.label, self.toggle)
                elif self.algo == AS:
                    Timer = glib.timeout_add(MILLI, on_timeout_as,
                        self.board, self.label, self.toggle)
                elif self.algo == TR:
                    Timer = glib.timeout_add(MILLI, on_timeout_tr,
                        self.board, self.label, self.toggle)
                else:
                    Timer = None

        # Radio buttons.
        if ident < 8 and widget.get_active():
            if ident < 5:
                self.algo = ident
            else:
                self.mazeid = ident - 5
            # Set up for a new run.
            self.setup_run(widget)

        return

    #
    # s e t u p _ r u n
    #
    # Class Frame - set up for a new run.
    #
    # Returns:  Nothing     Always
    #
    def setup_run(self, widget):
        """ Docstring placeholder.
        """
        global Curid, Curstep, Dirn, Flags, Ticks, Timer

        # Kill any running timer.
        if Timer != None:
            glib.source_remove(Timer)
            Timer = None
        Ticks = 0

        # Kill the self's sign-on.
        if self.rsig != None:
            self.board.disconnect(self.rsig)
            self.rsig = None
        if self.esig != None:
            self.board.disconnect(self.esig)
            self.esig = None

        # Reset the window title.
        if self.mazeid == 2 and Flags["maz"]:
            s, t, u = Flags["mazfile"].rpartition("/")
            self.win.set_title("Local maze file is " + u)
        else:
            self.win.set_title("Maze is " + self.board.mazenames[self.mazeid])

        # Reset the pause button.
        self.toggle.handler_block(self.handler)
        self.toggle.set_active(False)
        self.toggle.set_sensitive(True)
        self.toggle.set_label("Pause")
        self.toggle.handler_unblock(self.handler)

        # Reset the progress text.
        self.label.set_label("Wait ...")

        # Initialise the drawing area.
        #self.draw = gtk.DrawingArea()
        #self.draw.set_size_request(BDSIZE, BDSIZE)

        # Initialise the current Board.
        Curid = START
        Dirn = UP
        Curstep = 0
        board = self.board
        board.algo = self.algo
        board.mazeid = self.mazeid
        if not board.build_board():
            return

        # Initialise the tile data.
        for j in range(TILES):
            board.tiles[j].setclosed(False)
            board.tiles[j].setcost(0)
            # distances are used only by the A* algorithm.
            if self.algo == AS:
                board.tiles[j].setheuristic(board.distances[1][j])
            else:
                board.tiles[j].setheuristic(0)
            # board.tiles[j].setid(j)
            board.tiles[j].setmarked(False)
            board.tiles[j].setopen(False)
            board.tiles[j].setparent(INVALID)
            board.tiles[j].setstate(0)
            board.tiles[j].setvisible(0)

        # Clear the mouse.
        board.set_mouse_color(Curid, BGND)

        return

#
# Class Usage
#
# Usage message handling.
#
class Usage(Exception):
    """Docstring placeholder.
    """
    #
    # U s a g e . _ _ i n i t _ _
    #
    # Class Usage - initialise a Usage message.
    #
    # Returns:  Nothing     Always
    #
    def __init__(self, msg):
        self.msg = msg
        return

#
# Module functions.
#

#
# e x i s t s
#
# Search for an executable on the path.
#
# Returns:  the executable's path   Success
#           None                    Otherwise
#
def exists(program):
    """ Docstring placeholder.
    """
    fpath, fname = os.path.split(program)
    if fpath:
        if os.path.exists(program) and os.access(program, os.X_OK):
            return program
    else:
        for path in os.environ["PATH"].split(os.pathsep):
            executable = os.path.join(path, program)
            if os.path.exists(executable) and os.access(executable, os.X_OK):
                return executable

    return None

#
# c o l s t a t e
#
# Get a tile's column data.
#
# Returns:  a tuple containing UP/DN/WALL flags.
#
def colstate(ident, state):
    """ Docstring placeholder
    """
    f = 0
    g = 0
    h = 0
    d = state[ident]
    # Find the required value.
    if d & UP_ONE:
        f = 1
    if d & UP_TWO:
        f = 2
    if d & DN_ONE:
        g = 1
    if d & DN_TWO:
        g = 2
    if d & UP_WALL:
        h |= UP
    if d & DN_WALL:
        h |= DOWN

    return (f, g, h)

#
# r o w s t a t e
#
# Get a tiles row data.
#
# Returns:  a tuple containing RT/LT/WALL flags.
#
def rowstate(ident, state):
    """ Docstring placeholder
    """
    f = 0
    g = 0
    h = 0
    d = state[ident]
    # Find the required value.
    if d & LT_ONE:
        f = 1
    if d & LT_TWO:
        f = 2
    if d & RT_ONE:
        g = 1
    if d & RT_TWO:
        g = 2
    if d & LT_WALL:
        h |= LEFT
    if d & RT_WALL:
        h |= RIGHT

    return (f, g, h)

#
# d u m p h e a d e r
#
# Dump a dot file header to a file.
#
# Returns:  Nothing     Always
#
def dumpheader(fp, maze, algo):
    """ Docstring placeholder
    """
    global Flags

    hdr = time.strftime("Printed at %H:%M on %a, %d %b %Y", time.localtime())

    print >> fp, (
        "/*@\n"
        "** mazedot.dot - mouse maze path data.\n"
        "**\n"
        "** mazes.py: " + VERSION_ID + ".\n"
        "**\n"
        "** " + hdr + ".\n"
        "**\n"
        "** There are problems setting a node font size which works\n"
        "** in both dot and svg files. The best bet seems to be to\n"
        "** set the svg value explicitly on the command line.\n"
        "**\n"
        "** Compile with: dot -Tsvg -Nfontsize=10 maze.dot >maze.svg\n"
        "*/\n"
        "digraph G {\n"
        "  /* Defaults */\n"
        "  ordering=out;\n"
        "  //nodesep=1.0;\n"
        "  //ranksep=1.0;\n"
        "  shape=plaintext;\n"
        "  fontsize=16;\n"
        "  fontname=\"Times-Bold\";\n"
        "  label=\"Maze %s, algorithm %s\";\n"
        "  node [shape=circle];\n"
        "  edge [dir=none];\n"
        "  /* Data nodes */\n" % (maze, algo)
        ),

    return

#
# d u m p r o w
#
# Dump a row of a maze to a file, in dot file format.
#
# Returns:  Nothing     Always
#
# Node types:
#   N - not visited
#   V - visited
#   M - marked
# Line types:
#   N -> N - dotted
#   N -> V - dotted
#   N -> M - dotted
#   V -> N - dotted
#   V -> V - solid
#   V -> M - solid
#   M -> N - dotted
#   M -> V - solid
#   M -> M - blue
#
def dumprow(fp, name, lastrow, base, state, board):
    """ Docstring placeholder
    """

    # Rank the nodes.
    print >> fp, "  {rank=same;",
    for j in range(16):
        print >> fp, " %s%02d" % (name, j),
    print >> fp, "}"

    algo = board.algo

    # Column edges.
    if base > 15:
        for j in range(16):
            if algo == WF or algo == FF or algo == AS:
                # Get the data.
                m = state[base + j - 16] & VISITED
                n = state[base + j - 16] & MARKED
                if n != 0:
                    m = 0
                p = state[base + j - 16]
                q = state[base + j] & MARKED
                r = state[base + j] & VISITED
                if q != 0:
                    r = 0
                s = state[base + j]
                # Print the data.
                if (p & DOWN) or (s & UP):
                    # Wall.
                    print >> fp, "  %s%02d -> %s%02d [style=invis];" % (lastrow, j, name, j)
                elif n != 0 and q != 0:
                    # Shortest path edge.
                    print >> fp, "  %s%02d -> %s%02d [style=bold,color=blue];" % (lastrow, j, name, j)
                elif (m != 0 and r != 0) or (m != 0 and q != 0) or (n != 0 and r != 0):
                    # Used edge.
                    print >> fp, "  %s%02d -> %s%02d [style=solid];" % (lastrow, j, name, j)
                else:
                    # Unused edge.
                    print >> fp, "  %s%02d -> %s%02d [style=dotted];" % (lastrow, j, name, j)
            elif algo == TR:
                # We have tuples containing UP/DN/WALL flags.
                m, n, p = colstate(base + j - 16, state)
                q, r, s = colstate(base + j, state)
                # Print the data.
                if (p & DOWN) or (s & UP):
                    # Wall.
                    print >> fp, "  %s%02d -> %s%02d [style=invis];" % (lastrow, j, name, j)
                elif n == 0 and q == 0:
                    # Unused edge.
                    print >> fp, "  %s%02d -> %s%02d [style=dotted];" % (lastrow, j, name, j)
                elif n == q:
                    # Used edge.
                    print >> fp, "  %s%02d -> %s%02d [style=bold,color=blue,headlabel=\"%d\",taillabel=\"%d\"];" % (lastrow, j, name, j, n, q)
                else:
                    # Corrupt edge.
                    print >> fp, "  %s%02d -> %s%02d [style=bold,color=red,headlabel=\"%d\",taillabel=\"%d\"];" % (lastrow, j, name, j, n, q)

    # Node labels - print the node id and possibly some other stuff.
    for j in range(16):
        if algo == WF:
            print >> fp, "  %s%02d [label=\"%03d\"]" % (name, j, base + j)
        elif algo == FF:
            print >> fp, "  %s%02d [label=\"%03d\"]" % (name, j, base + j)
        elif algo == AS:
            # For A*, add the cost to reach this node.
            if board.tiles[base + j].getstate() != 0:
                k = board.tiles[base + j].getcost() + board.tiles[base + j].getheuristic() * 10
                print >> fp, "  %s%02d [label=\"%03d\\n%03d\"]" % (name, j, base + j, k / 10)
            else:
                print >> fp, "  %s%02d [label=\"%03d\"]" % (name, j, base + j)
        elif algo == TR:
            # For Tremaux, add the first step to reach this node.
            if board.tiles[base + j].getstate() & VISITED:
                print >> fp, "  %s%02d [label=\"%03d\\n%03d\"]" % (name, j, base + j, board.steps[base + j])
            else:
                print >> fp, "  %s%02d [label=\"%03d\"]" % (name, j, base + j)

    # Row edges (sixteen nodes, fifteen edges).
    for j in range(1, 16):
        if algo == WF or algo == FF or algo == AS:
            # Get the data.
            m = state[base + j - 1] & VISITED
            n = state[base + j - 1] & MARKED
            if n != 0:
                m = 0
            p = state[base + j - 1]
            q = state[base + j] & MARKED
            r = state[base + j] & VISITED
            if q != 0:
                r = 0
            s = state[base + j]
            # Print the data.
            if (p & RIGHT) or (s & LEFT):
                print >> fp, "  %s%02d -> %s%02d [style=invis];" % (name, j - 1, name, j)
            elif n != 0 and q != 0:
                print >> fp,  "  %s%02d -> %s%02d [style=bold,color=blue];" % (name, j - 1, name, j)
            elif (m != 0 and r != 0) or (m != 0 and q != 0) or (n != 0 and r != 0):
                print >> fp, "  %s%02d -> %s%02d [style=solid];" % (name, j - 1, name, j)
            else:
                print >> fp, "  %s%02d -> %s%02d [style=dotted];" % (name, j - 1, name, j)
        elif algo == TR:
            # We have tuples containing RT/LT/WALL flags.
            m, n, p = rowstate(base + j - 1, state)
            q, r, s = rowstate(base + j, state)
            # Print the data.
            if (p & RIGHT) or (s & LEFT):
                print >> fp, "  %s%02d -> %s%02d [style=invis];" % (name, j - 1, name, j)
            elif n == 0 and q == 0:
                print >> fp, "  %s%02d -> %s%02d [style=dotted];" % (name, j - 1, name, j)
            elif n == q:
                print >> fp,  "  %s%02d -> %s%02d [style=bold,color=blue,label=\"%d:%d\"];" % (name, j - 1, name, j, n, q)
            else:
                print >> fp,  "  %s%02d -> %s%02d [style=bold,color=red,label=\"%d:%d\"];" % (name, j - 1, name, j, n, q)

    return

#
# d u m p d o t
#
# Dump a maze solution to a file in dot file format.
#
# Returns:  True    Success
#           False   Otherwise
#
def dumpdot(board, name, maze, algo, once):
    """ Docstring placeholder
    """
    state = [0] * TILES

    # Run this function exactly once.
    try:
        dumpdot.flg |= 1
    except AttributeError:
        dumpdot.flg = 0
    if once and dumpdot.flg != 0:
        return False

    dotfile = name + ".dot"
    svgfile = name + ".svg"

    try:
        fp = open(dotfile, "w")
    except IOError:
        if Flags["dbg"]:
            Log.debug("In dumpdot(): could not open file %s for writing", dotfile)
        return

    # Collect all the tile state into one array.
    for j in range(TILES):
        state[j] = board.tiles[j].getstate()

    dumpheader(fp, maze, algo)
    base = 0
    lastrow = "z"
    for row in ("a", "b", "c", "d", "e", "f", "g", "h", "j", "k", "m", "n", "p", "q", "r", "s"):
        dumprow(fp, row, lastrow, base, state, board)
        lastrow = row
        base += 16
    print >> fp, "}"

    fp.close()

    # If dot is available, convert the dot file to SVG.
    if exists("dot") != None:
        s = "dot -Tsvg %s > %s" % (dotfile, svgfile)
        os.system(s)

    return True

#
# a d j a c e n t
#
# Find the valid adjacent tiles for a given tile.
#
# Returns:  a list of valid ids     Always
#
def adjacent(board, ident):
    """ Docstring placeholder.
    """
    idents = []
    for dirn in (UP, RIGHT, DOWN, LEFT):
        if board.check_move(ident, dirn):
            idents.append(ident + delta_id(dirn))
    return idents

#
# d e l t a _ d i r n
#
# Find the change in direction for a given id.
#
# Returns:  the delta dirn    Success
#           BAD               Otherwise
#
# NB. The move must be valid.
#
def delta_dirn(ident):
    """ Docstring placeholder.
    """
    updates = (
        # Direction, delta-id
        (BAD, INVALID),
        (UP, -16),
        (RIGHT, 1),
        (DOWN, +16),
        (LEFT, -1)
        )
    for u in updates:
        if ident == u[1]:
            return u[0]

    return BAD

#
# d e l t a _ i d
#
# Find the change in id for a given direction.
#
# Returns:  the delta id      Success
#           INVALID           Otherwise
#
# NB. The move must be valid.
#
def delta_id(dirn):
    """ Docstring placeholder.
    """
    updates = (
        # Direction, delta-id
        (BAD, INVALID),
        (UP, -16),
        (RIGHT, 1),
        (DOWN, +16),
        (LEFT, -1)
        )
    for u in updates:
        if dirn == u[0]:
            return u[1]

    return INVALID

#
# d u m p p a r e n t
#
# Dump the board's parent values to the terminal.
#
# Returns:  Nothing     Always
#
def dumpparent(board):
    """ Docstring placeholder.
    """
    # Run this function exactly once.
    try:
        dumpparent.flg |= 1
    except AttributeError:
        dumpparent.flg = 0
    if once and dumpparent.flg != 0:
        return

    for j in range(TILES):
        print "%s/%s" % (repr(j).rjust(3), repr(board.tiles[j].getparent()).ljust(3)),
        if j % 8 == 7:
            print
    print

    return

#
# m a r k p a r e n t
#
# Mark the sequence of parent tiles back to the start point.
#
# Returns:  the number of tiles marked  Always
#
# The Tile.cost is re-used to store the visit count.
#
def markparent(board, ident):
    """ Docstring placeholder.
    """
    parent = ident
    total = 0
    # Run back down the chain.
    while parent != START:
        total += 1
        board.tiles[parent].setmarked(True)
        board.tiles[parent].setcost(total)
        p = parent
        parent = board.tiles[parent].getparent()
        if False and Flags["dbg"]:
            Log.debug("In markparent(): child %3d parent %3d", parent, p)

    # Finally mark the start tile.
    total += 1
    board.tiles[parent].setmarked(True)
    board.tiles[parent].setcost(total)

    return total

#
# r e v e r s e
#
# Find the reverse of a direction.
#
# Returns:  the reverse of a direction  Success
#           BAD                         Otherwise
#
def reverse(dirn):
    """ Docstring placeholder.
    """
    if dirn == UP:
        d = DOWN
    elif dirn == RIGHT:
        d = LEFT
    elif dirn == DOWN:
        d = UP
    elif dirn == LEFT:
        d = RIGHT
    else:
        d = BAD

    return d

#
# d i r n l i s t _ f f
#
# Get a list of absolute directions to check.
#
# Returns:  a tuple containing the directions  Success
#           a tuple containing BAD             Otherwise
#
def dirnlist_ff(dirn):
    """ Docstring placeholder.
    """
    if dirn == UP:
        ds = (UP, RIGHT, DOWN, LEFT)
    elif dirn == RIGHT:
        ds = (RIGHT, DOWN, LEFT, UP)
    elif dirn == DOWN:
        ds = (DOWN, LEFT, UP, RIGHT)
    elif dirn == LEFT:
        ds = (LEFT, UP, RIGHT, DOWN)
    else:
        ds = (BAD, BAD, BAD, BAD)

    return ds

#
# u p d a t e _ f f
#
# Update the search with a new direction to move in.
#
# Return:   the new direction   Success
#           BAD                 Otherwise
#
# This is used only by the flood fill algorithm.
#
def update_ff(board, ident, dirn):
    """ Docstring placeholder.
    """
    status = False
    for nd in dirnlist_ff(dirn):
        # Get the first available exit.
        if board.check_move(ident, nd):
            d = delta_id(nd)
            if not board.tiles[ident + d].ismarked():
                status = True
                break
    # No exit, get parent.
    if not status:
        parent = board.tiles[ident].getparent()
        nd = delta_dirn(parent - ident)

    return nd

#
# o n _ t i m e o u t _ f f
#
# Timeout handler for flood fill algorithm.
#
# Returns:  True    Keep the timer running
#           False   Stop the timer
#
# Localised flood fill.
#
# Until the TARGET tile is reached:
#     Flag the current tile MARKED.
#     Check each adjacent tile in turn, and move to the first unmarked tile.
#     If all adjacent tiles are marked, move to the current tiles' parent.
#
def on_timeout_ff(board, label, toggle):
    """ Docstring placeholder.
    """
    global Curid, Dirn, Targetdirn, Ticks, Timer

    # Update the Tile state for use by dumpdot(), since it
    # isn't used for anything else.  The Tiles' marked()
    # flag is added below, to show the final path.
    s = board.tiles[Curid].getstate() | board.maze[Curid]
    board.tiles[Curid].setstate(s)

    # We stop when we've reached the target or got back to the start after that.
    if (Curid == TARGET and not Flags["full"]) or (Curid == START and Targetdirn != BAD):
        # Update the final direction.
        if Targetdirn != BAD:
            Dirn = Targetdirn
        # Show the final path.
        for j in range(TILES):
            board.tiles[j].setmarked(False)
        total = markparent(board, Curid)
        for j in range(TILES):
            if board.tiles[j].ismarked():
                s = board.tiles[j].getstate()
                board.tiles[j].setstate(s | MARKED)
                board.set_mouse_color(j, BLUE)
        # Count the tiles visited.
        count = 0
        for j in range(TILES):
            if board.tiles[j].getparent() != INVALID:
                count = count + 1
        # Dump a dot/svg file showing the board's state.
        if Flags["svg"]:
            s = Flags["svgfile"]
            t, u, v = Flags["mazfile"].rpartition("/")
            dumpdot(board, s, v, "Flood Fill, node data id", False)
        s = str.format("Visited: %d\nPath:    %d\nSteps:  %d" % (count, total, Ticks))
        label.set_label(s)
        if Flags["vrb"] and Flags["maz"]:
            t, u, v = Flags["mazfile"].rpartition("/")
            print "Algorithm: %s Maze: %s Visited: %3d Path: %3d Steps: %3d" % ("FF", v, count, total, Ticks)
        if Flags["dbg"]:
            Log.debug("In on_timeout_ff(): reached goal via %d nodes", total)
        toggle.set_sensitive(False)
        if Flags["auto"]:
            gtk.main_quit()
        return False
    elif Curid == START and Ticks != 0:
        # If we're back at START without visiting TARGET, we've failed.
        s = str.format("Run failed")
        label.set_label(s)
        if Flags["dbg"]:
            Log.debug("In on_timeout_ff(): run failed")
        if Flags["auto"]:
            gtk.main_quit()
        return False
    else:
        # Update the step count for each working step.
        Ticks = Ticks + 1
        if Curid == TARGET:
            Targetdirn = Dirn
        board.tiles[Curid].setmarked(True)
        # Find an unused exit.
        nd = update_ff(board, Curid, Dirn)
        d = delta_id(nd)
        if board.tiles[Curid + d].getparent() == INVALID:
            board.tiles[Curid + d].setparent(Curid)
            board.set_mouse_color(Curid + d, GREEN)
        elif board.tiles[Curid].ismarked():
            board.set_mouse_color(Curid, YELLOW)
        else:
            board.set_mouse_color(Curid + d, GREEN)
        Curid = Curid + d
        Dirn = nd
        s = board.tiles[Curid].getstate()
        board.tiles[Curid].setstate(s | VISITED)

    # Return False to destroy the timer.
    return True

#
# d i r n l i s t _ w f
#
# Get a list of absolute directions to check.
#
# Returns:  a tuple containing the directions  Success
#           a tuple containing BAD             Otherwise
#
# This is used only by the wall follower algorithm:
#    if open right then go right
#    else if open ahead then go ahead
#    else if open left then go left
#    else bounce
#
def dirnlist_wf(dirn):
    """ Docstring placeholder.
    """
    if dirn == UP:
        ds = (RIGHT, UP, LEFT, DOWN)
    elif dirn == RIGHT:
        ds = (DOWN, RIGHT, UP, LEFT)
    elif dirn == DOWN:
        ds = (LEFT, DOWN, RIGHT, UP)
    elif dirn == LEFT:
        ds = (UP, LEFT, DOWN, RIGHT)
    else:
        ds = (BAD, BAD, BAD, BAD)

    return ds

#
# o n _ t i m e o u t _ w f
#
# Timeout handler for wall follower algorithm.
#
# Returns:  True    Keep the timer running
#           False   Stop the timer
#
def on_timeout_wf(board, label, toggle):
    """ Docstring placeholder.
    """
    global Curid, Dirn, Ticks, Timer

    # Update the Tile state for use by dumpdot(), since it
    # isn't used for anything else.  The Tiles' marked()
    # flag is added below, to show the final path.
    s = board.tiles[Curid].getstate() | board.maze[Curid]
    board.tiles[Curid].setstate(s)

    if Curid == TARGET:
        # Show the final path.
        for j in range(TILES):
            board.tiles[j].setmarked(False)
        total = markparent(board, Curid)
        for j in range(TILES):
            if board.tiles[j].ismarked():
                s = board.tiles[j].getstate()
                board.tiles[j].setstate(s | MARKED)
                board.set_mouse_color(j, BLUE)
        # Count the tiles visited (start has no parent).
        count = 1
        for j in range(TILES):
            if board.tiles[j].getparent() != INVALID:
                count = count + 1
        # Dump a dot/svg file showing the board's state.
        if Flags["svg"]:
            s = Flags["svgfile"]
            t, u, v = Flags["mazfile"].rpartition("/")
            dumpdot(board, s, v, "Wall Follower, node data id", False)
        s = str.format("Visited: %d\nPath:    %d\nSteps:  %d" % (count, total, Ticks))
        label.set_label(s)
        if Flags["vrb"] and Flags["maz"]:
            t, u, v = Flags["mazfile"].rpartition("/")
            print "Algorithm: %s Maze: %s Visited: %3d Path: %3d Steps: %3d" % ("WF", v, count, total, Ticks)
        if Flags["dbg"]:
            Log.debug("In on_timeout_wf(): reached goal via %d nodes", total)
        toggle.set_sensitive(False)
        if Flags["auto"]:
            gtk.main_quit()
        return False
    elif Curid == START and Ticks != 0:
        # If we've returned to the start, we've failed.
        s = str.format("Run failed")
        label.set_label(s)
        if Flags["dbg"]:
            Log.debug("In on_timeout_wf(): run failed")
        if Flags["auto"]:
            gtk.main_quit()
        return False
    else:
        # Update the step count for each working step.
        Ticks = Ticks + 1
        # Try to move to the (relative) right.
        for nd in dirnlist_wf(Dirn):
            # Get the first available exit.
            if board.check_move(Curid, nd):
                board.set_mouse_color(Curid, YELLOW)
                d = delta_id(nd)
                # Avoid dead ends (twice-visited tiles).
                if board.tiles[Curid + d].getparent() == INVALID:
                    board.tiles[Curid + d].setparent(Curid)
                Curid = Curid + d
                Dirn = nd
                s = board.tiles[Curid].getstate()
                board.tiles[Curid].setstate(s | VISITED)
                board.set_mouse_color(Curid, GREEN)
                break

    # Return False to destroy the timer.
    return True

#
# u p d a t e _ a s
#
# Update the search in the light of a newly discovered tile.
#
# Returns:  Nothing     Always
#
# Used only by the A* algorithm.
#
# If the tile is not accessible, or on the closed list,
#   then ignore it.
# If the tile isn't on the open list,
#   then add it and update its parent and cost fields.
# If the tile is on the open list
#   then check its G + H value.
#   If the new value is lower than the current value
#     then the new path is better.
#     Update the parent and cost fields
#     and rebuild the open queue.
#
def update_as(board, parent, ident):
    """ Docstring placeholder.
    """
    g = board.tiles[parent].getcost() + 10
    h = g + board.tiles[ident].getheuristic() * 10
    if board.tiles[ident].isopen():
        ch = board.tiles[ident].getcost() + board.tiles[ident].getheuristic() * 10
        if ch > h:
            # Queue must be rebuilt on cost change.
            if Flags["dbg"]:
                Log.debug("In update_as(): rebuild needed at ident %d Old h %d New h %d", ident, ch, h)
            # Set the current tile id to INVALID (256)
            # Copy the tile, update the copy, and add it to the tiles list.
            # Sort the tiles list by id.
            # Add the new tile to the open queue.
            board.tiles[ident].setid(INVALID)
            nt = copy.deepcopy(board.tiles[ident])
            nt.setid(ident)
            nt.setcost(g)
            nt.setparent(parent)
            board.tiles.append(nt)
            board.tiles.sort(key=Tile.getid)
            # Used for debugging only.
            if False:
                for j in range(len(board.tiles)):
                    print board.tiles[j]
            board.queue.put(board.tiles[ident])
    else:
        board.tiles[ident].setcost(g)
        board.tiles[ident].setparent(parent)
        board.tiles[ident].setopen(True)
        board.queue.put(board.tiles[ident])
        if Flags["dbg"]:
            Log.debug("In update_as(): added tile %d", ident)

    return

#
# o n _ t i m e o u t _ a s
#
# Timeout handler for A* algorithm.
#
# Returns:  True    Keep the timer running
#           False   Stop the timer
#
def on_timeout_as(board, label, toggle):
    """ Docstring placeholder.
    """
    global Curid, Dirn, Ticks

    # Update the Tile state for use by dumpdot(), since it
    # isn't used for anything else.  The Tiles' marked()
    # flag is added below, to show the final path.
    s = board.tiles[Curid].getstate() | board.maze[Curid]
    board.tiles[Curid].setstate(s)

    if Curid == TARGET:
        # Show the final path.
        total = markparent(board, Curid)
        for j in range(TILES):
            if board.tiles[j].ismarked():
                s = board.tiles[j].getstate()
                board.tiles[j].setstate(s | MARKED)
                board.set_mouse_color(j, BLUE)
        # Count the tiles visited.
        count = 0
        for j in range(TILES):
            if board.tiles[j].isclosed():
                count = count + 1
        # Dump a dot/svg file showing the board's state.
        if Flags["svg"]:
            s = Flags["svgfile"]
            t, u, v = Flags["mazfile"].rpartition("/")
            dumpdot(board, s, v, "A*, node data id/path cost + heuristic", False)
        # The A* algorithm uses the first tick to initialise the start tile status.
        s = str.format("Visited: %d\nPath:    %d\nSteps:  %d" % (count, total, Ticks - 1))
        label.set_label(s)
        if Flags["vrb"] and Flags["maz"]:
            t, u, v = Flags["mazfile"].rpartition("/")
            print "Algorithm: %s Maze: %s Visited: %3d Path: %3d Steps: %3d" % ("AS", v, count, total, Ticks)
        if Flags["dbg"]:
            Log.debug("In on_timeout_as(): reached goal via %d nodes", total)
        toggle.set_sensitive(False)
        if Flags["auto"]:
            gtk.main_quit()
        return False
    else:
        # Update the step count for each working step.
        Ticks = Ticks + 1
        # Select the best new tile.
        while True:
            if board.queue.empty():
                if Flags["dbg"]:
                    print "Run failed, queue empty."
                s = str.format("Run failed\nqueue empty")
                label.set_label(s)
                if Flags["dbg"]:
                    Log.debug("In on_timeout_as(): run failed, queue empty")
                if Flags["auto"]:
                    gtk.main_quit()
                return False
            tile = board.queue.get()
            ident = tile.getid()
            if (ident == INVALID):
                if Flags["dbg"]:
                    Log.debug("In on_timeout_as(): invalid tile %d found in queue", ident)
            else:
                break
        board.tiles[ident].setopen(False)
        # Get a list of adjacent tiles, and update them.
        children = adjacent(board, ident)
        if Flags["dbg"]:
            Log.debug("In on_timeout_as(): parent %d children %s", ident, str(children))
        for child in children:
            if not board.tiles[child].isclosed():
                update_as(board, ident, child)
        board.tiles[ident].setclosed(True)
        if Flags["dbg"]:
            Log.debug("In on_timeout_as(): queue size %d", board.queue.qsize())
        Curid = ident
        s = board.tiles[Curid].getstate()
        board.tiles[Curid].setstate(s | VISITED)
        board.set_mouse_color(Curid, GREEN)

    # Return False to destroy the timer.
    return True

#
# d u m p t i l e _ t r
#
# Dump a tile's state value to the terminal.
#
# Returns:  Nothing     Always
#
# This is used only by the Tremaux algorithm.
#
def dumptile_tr(board, ident):
    """ Docstring placeholder.
    """
    if Dirn == UP:
        s = "UP"
    elif Dirn == RIGHT:
        s = "RT"
    elif Dirn == DOWN:
        s = "DN"
    elif Dirn == LEFT:
        s = "LT"
    else:
        s = "BAD"

    # Show the current id and direction.
    n = board.tiles[ident].getstate()
    b = ((n & VISITED) != 0)
    print "%s -> step %d direction %s visited %s" % (repr(ident).rjust(3), Curstep, s, str(b))
    # Show the values.
    print "%s %d %s" % (repr(ident).rjust(3), n, readable_tr(n))

    return

#
# m a r k o n c e _ t r
#
# Mark the sequence of single edges back to the start point.
#
# Returns:  the number of tiles marked  Sucess
#           0                           Otherwise
#
# This is used only by the Tremaux algorithm.
# The Tile.cost is re-used to store the visit count.
#
def markonce_tr(board, ident):
    """ Docstring placeholder.
    """
    dirn = reverse(Dirn)
    total = 0
    while ident != START:
        total += 1
        board.tiles[ident].setmarked(True)
        board.tiles[ident].setcost(total)
        n = board.tiles[ident].getstate()
        r = reverse(dirn)
        if not (r == UP) and not (n & UP_WALL) and (n & UP_ONE) and not (n & UP_TWO):
            dirn = UP
        elif not (r == RIGHT) and not (n & RT_WALL) and (n & RT_ONE) and not (n & RT_TWO):
            dirn = RIGHT
        elif not (r == DOWN) and not (n & DN_WALL) and (n & DN_ONE) and not (n & DN_TWO):
            dirn = DOWN
        elif not (r == LEFT) and not (n & LT_WALL) and (n & LT_ONE) and not (n & LT_TWO):
            dirn = LEFT
        else:
            dirn = BAD
        ident = ident + delta_id(dirn)
        if dirn == BAD:
            if Flags["dbg"]:
                Log.debug("In markonce(): bad direction.")
            return 0

    # Finally mark the start tile.
    total += 1
    board.tiles[ident].setmarked(True)
    board.tiles[ident].setcost(total)

    return total

#
# r e a d a b l e _ t r
#
# Convert a tile's state values into a human-readable string.
#
# Returns:  a string containing the tile's state.
#
# This is used only by the Tremaux algorithm.
#
def readable_tr(state):
    """ Docstring placeholder.
    """
    s = " "
    if (state & UP_ONE):
        s += "UP_ONE "
    if (state & UP_TWO):
        s += "UP_TWO "
    if (state & UP_WALL):
        s += "UP_WALL "

    if (state & RT_ONE):
        s += "RT_ONE "
    if (state & RT_TWO):
        s += "RT_TWO "
    if (state & RT_WALL):
        s += "RT_WALL "

    if (state & DN_ONE):
        s += "DN_ONE "
    if (state & DN_TWO):
        s += "DN_TWO "
    if (state & DN_WALL):
        s += "DN_WALL "

    if (state & LT_ONE):
        s += "LT_ONE "
    if (state & LT_TWO):
        s += "LT_TWO "
    if (state & LT_WALL):
        s += "LT_WALL "

    return s

#
# u p d a t e _ t r
#
# Update the search with a new direction to move in.
#
# Return:   the new direction   Success
#           BAD                 Otherwise
#
# This is used only by the Tremaux algorithm.
# The Tile.cost is used to store the visit count.
#
# On the first visit:
#    If there is an unused edge,
#       return it
#    otherwise
#       return the current edge.
# On subsequent visits:
#    If the current edge has been used once,
#        return it
#    If the current edge has been used twice,
#        return an unused edge,
#        or a once-used edge,
#        or terminate.
#
def update_tr(board, dirn):
    """ Docstring placeholder.
    """
    global Curid, Dirn

    # Sets of tile state flags.
    checks = (
        (UP, DOWN, UP_WALL, UP_ONE, UP_TWO, DN_ONE, DN_TWO),
        (RIGHT, LEFT, RT_WALL, RT_ONE, RT_TWO, LT_ONE, LT_TWO),
        (DOWN, UP, DN_WALL, DN_ONE, DN_TWO, UP_ONE, UP_TWO),
        (LEFT, RIGHT, LT_WALL, LT_ONE, LT_TWO, RT_ONE, RT_TWO)
        )

    # Convert directions to array indices.
    idx = {UP:0, RIGHT:1, DOWN:2, LEFT:3}

    state = board.tiles[Curid].getstate()

    # Update the tile with the current move.
    if Dirn == UP:
        if state & DN_ONE:
            state |= DN_TWO
        else:
            state |= DN_ONE
    elif Dirn == RIGHT:
        if state & LT_ONE:
            state |= LT_TWO
        else:
            state |= LT_ONE
    elif Dirn == DOWN:
        if state & UP_ONE:
            state |= UP_TWO
        else:
            state |= UP_ONE
    elif Dirn == LEFT:
        if state & RT_ONE:
            state |= RT_TWO
        else:
            state |= RT_ONE
    board.tiles[Curid].setstate(state)
    # Find the walls and update any edge data.
    #if board.check_move(Curid, UP):
    #    if board.tiles[Curid + delta_id(UP)].getstate() & DN_ONE:
    #        state |= UP_ONE
    #    if board.tiles[Curid + delta_id(UP)].getstate() & DN_TWO:
    #        state |= UP_TWO
    #else:
    #    state |= UP_WALL
    #
    # Find the walls and update any edge data (compact version).
    k = idx[Dirn]
    for j in range(4):
        a, b, c, d, e, f, g = checks[(k + j) % 4]
        if board.check_move(Curid, a):
            if board.tiles[Curid + delta_id(a)].getstate() & f:
                state |= d
            if board.tiles[Curid + delta_id(a)].getstate() & g:
                state |= e
        else:
            state |= c
    # If this is an unvisited tile.
    if not (state & VISITED):
        state |= VISITED
        board.tiles[Curid].setcost(1)
        dirn = BAD
        # Check for an unused edge.
        #if not (state & UP_WALL) and not (state & UP_ONE) and not (state & UP_TWO):
        #    dirn = UP
        #    state |= UP_ONE
        #
        # Check for an unused edge, preferring the current direction (compact version).
        k = idx[Dirn]
        for j in range(4):
            a, b, c, d, e, f, g = checks[(k + j) % 4]
            if not state & c and not state & d and not state & e:
                dirn = a
                state |= d
                break
        # If there's no unused edge, reverse direction.
        if dirn == BAD:
            dirn = reverse(Dirn)
            if dirn == UP:
                state |= UP_TWO
            elif dirn == RIGHT:
                state |= RT_TWO
            elif dirn == DOWN:
                state |= DN_TWO
            elif dirn == LEFT:
                state |= LT_TWO
        # Update the current tile
        board.tiles[Curid].setstate(state)
        Dirn = dirn
    # We've been here before.
    else:
        board.tiles[Curid].setcost(board.tiles[Curid].getcost() + 1)
        dirn = BAD
        # Current edge used once (NB. in fact there's no point in checking for a wall).
        #if Dirn == UP and not (state & DN_WALL) and (state & DN_ONE) and not (state & DN_TWO):
        #        dirn = DOWN
        #        state |= DN_TWO
        #
        # Current edge used once (compact version).
        k = idx[Dirn]
        for j in range(4):
            a, b, c, d, e, f, g = checks[(k + j) % 4]
            if Dirn == b and not state & c and state & d and not state & e:
                dirn = a
                state |= e
                break
        board.tiles[Curid].setstate(state)
        # Current edge used twice.
        if dirn == BAD:
            # Check for an unused edge.
            #if not (state & UP_WALL) and not (state & UP_ONE) and not (state & UP_TWO):
            #    dirn = UP
            #    state |= UP_ONE
            # Check for a once-used edge.
            #if not (state & UP_WALL) and not (state & UP_TWO):
            #    dirn = UP
            #    state |= UP_TWO
            #
            # Check for an unused edge (compact version).
            k = idx[Dirn]
            for j in range(4):
                a, b, c, d, e, f, g = checks[(k + j) % 4]
                if not state & c and not state & d and not state & e:
                    dirn = a
                    state |= d
                    break
            if dirn == BAD:
                # Check for a once-used edge.
                k = idx[Dirn]
                for j in range(4):
                    a, b, c, d, e, f, g = checks[(k + j) % 4]
                    if not state & c and not state & e:
                        dirn = a
                        state |= e
                        break
            # Update the current tile
            if dirn == BAD:
                print "In update_tr(): tile %d step %d has bad direction" % (Curid, Curstep)
            else:
                board.tiles[Curid].setstate(state)
                Dirn = dirn

    # Return new direction, or BAD on failure.
    return dirn

#
# o n _ t i m e o u t _ t r
#
# Timeout handler for Tremaux' Algorithm
#
# Returns:  True    Keep the timer running
#           False   Stop the timer
#
def on_timeout_tr(board, label, toggle):
    """ Docstring placeholder.
    """
    global Curid, Curstep, Dirn, Flags, Ticks, Timer

    # Keep a list of the steps at which each tile is first reached.
    Curstep += 1
    if board.steps[Curid] == 0:
        board.steps[Curid] = Curstep

    if Curid == TARGET:
        # Update the tile with the current move.
        state = board.tiles[Curid].getstate()
        state |= VISITED
        if Dirn == UP:
            state |= DN_ONE
        elif Dirn == RIGHT:
            state |= LT_ONE
        elif Dirn == DOWN:
            state |= UP_ONE
        elif Dirn == LEFT:
            state |= RT_ONE
        board.tiles[Curid].setstate(state)
        # Count the tiles visited.
        count = 0
        for j in range(TILES):
            if board.tiles[j].getstate() & VISITED:
                count = count + 1
        # Highlight the final path, along the single-use edges.
        total = markonce_tr(board, Curid)
        for j in range(TILES):
            if board.tiles[j].ismarked():
                board.set_mouse_color(j, BLUE)
        # Dump a dot/svg file showing the board's state.
        if Flags["svg"]:
            s = Flags["svgfile"]
            t, u, v = Flags["mazfile"].rpartition("/")
            dumpdot(board, s, v, "Tremaux, node data id/step first visited", False)
        s = str.format("Visited: %d\nPath:    %d\nSteps:  %d" % (count, total, Ticks))
        label.set_label(s)
        if Flags["vrb"] and Flags["maz"]:
            t, u, v = Flags["mazfile"].rpartition("/")
            print "Algorithm: %s Maze: %s Visited: %3d Path: %3d Steps: %3d" % ("TR", v, count, total, Ticks)
        if Flags["dbg"]:
            Log.debug("In on_timeout_tr(): reached goal via %d nodes", total)
        toggle.set_sensitive(False)
        if Flags["auto"]:
            gtk.main_quit()
        return False
    elif Curid == START and Ticks != 0:
        # If we've returned to the start, we've failed.
        s = str.format("Run failed")
        label.set_label(s)
        if Flags["dbg"]:
            Log.debug("In on_timeout_tr(): run failed")
        if Flags["auto"]:
            gtk.main_quit()
        return False
    else:
        # Update the step count for each working step.
        Ticks = Ticks + 1
        # Get the direction of an unused path, or a path used only once.
        status = False
        nd = update_tr(board, Dirn)
        if nd == BAD:
            print "In on_timeout_tr(): Tile %d Step %d has bad direction" % (Curid, Curstep)
            return False

        # Used for debugging only.
        if False and Curid == 208:
            dumptile_tr(board, Curid)
            if (Curid % 16) > 0:
                dumptile_tr(board, Curid - 1)
            if (Curid % 16) < 15:
                dumptile_tr(board, Curid + 1)
            if Curid > 15:
                dumptile_tr(board, Curid - 16)
            if Curid < 240:
                dumptile_tr(board, Curid + 16)

        # Show the new mouse position.
        board.set_mouse_color(Curid, BGND)
        d = delta_id(nd)
        if board.tiles[Curid + d].getparent() == INVALID:
            board.tiles[Curid + d].setparent(Curid)
        Curid = Curid + d
        Dirn = nd
        board.set_mouse_color(Curid, GREEN)

    # Return False to destroy the timer.
    return True

#
# o n _ t i m e o u t _ s t a r t
#
# Trigger the start of a run.
#
# Returns:  False   Always
#
def on_timeout_start(frame):
    """ Docstring placeholder.
    """
    frame.button_s.emit("clicked")
    # Return False to destroy the timer.
    return False

#
# m a i n
#
# Main program of mazes.py.
#
# Returns: 0    Success
#          2    Otherwise
#
## Documentation for main()
#
#  @param  argv    Command line arguments
#  @retval         Return code
#
def main(argv=None):
    """ Docstring placeholder.

    @param  argv    Command line arguments
    @retval         Return code
    """
    global Flags, Log

    # Set default flag values
    Flags["auto"] = False
    Flags["dbg"] = False
    Flags["full"] = False
    Flags["log"] = False
    Flags["logfile"] = "logfile.log"
    Flags["maz"] = False
    Flags["mazfile"] = "maze.maz"
    Flags["path"] = Path
    Flags["svg"] = False
    Flags["svgfile"] = "svgfile"
    Flags["vrb"] = False

    # Parse command line options.
    if argv is None:
        argv = sys.argv
    try:
        # Run the parser.
        try:
            opts, args = getopt.getopt(argv[1:], "a:dhL:m:p:s:vV",
                ["auto=", "debug", "help", "log=", "maz=", "path=", "svg=", "verbose", "version"])
        except getopt.GetoptError, err:
            raise Usage(err)

        # Process the options.
        for o, a in opts:
            if o in ("-a", "--auto"):
                Flags["auto"] = True
                algo = a.upper()
            elif o in ("-d", "--debug"):
                Flags["dbg"] = True
            elif o in ("-h", "--help"):
                print "Usage: %s [options]" % os.path.basename(sys.argv[0])
                print (
                    "\n"
                    "options:\n"
                    "    -a, --auto ALG    Run in auto, algorithm WF|FF|AS|TR\n"
                    "    -d, --debug       Set the debugging flag\n"
                    "    -h, --help        Show this message and exit\n"
                    "    -L, --log FILE    Log messages to the log FILE\n"
                    "    -m, --maz FILE    Load the 'local' maze from the .maz FILE\n"
                    "    -p, --path PATH   Set the default PATH to the .maz files directory\n"
                    "    -s, --svg FILE    Write the solution to the dot/SVG FILE\n"
                    "    -v, --verbose     Set the verbose flag\n"
                    "    -V, --version     Show the version number\n"
                )
                return 0
            elif o in ("-L", "--log"):
                Flags["log"] = True
                Flags["logfile"] = a
            elif o in ("-m", "--maz"):
                Flags["maz"] = True
                Flags["mazfile"] = a
            elif o in ("-p", "--path"):
                if os.path.exists(a):
                    Flags["path"] = a
            elif o in ("-s", "--svg"):
                Flags["svg"] = True
                if a[-4:len(a)] == ".svg":
                    Flags["svgfile"] = a[0:-4]
                else:
                    Flags["svgfile"] = a
            elif o in ("-v", "--verbose"):
                Flags["vrb"] = True
            elif o in ("-V", "--version"):
                print "%s: %s" % (os.path.basename(sys.argv[0]), VERSION_ID)
                return 0
            else:
                assert False, "Unhandled option " + str(o)

        if Flags["auto"] and not algo in ("WF", "FF", "AS", "TR"):
            err = "Unknown algorithm " + algo + " (Use WF, FF, AS, or TR)."
            raise Usage(err)

    # Add a usage message.
    except Usage, err:
        print >> sys.stderr, err.msg
        print >> sys.stderr, "for help use --help"
        return 2

    # The debugging code often writes to the logfile.
    if Flags["dbg"]:
        Flags["log"] = True

    # Initialise the logger
    if Flags["log"]:
        logging.basicConfig(filename=Flags["logfile"], level=logging.DEBUG, filemode="w")
        Log = logging.getLogger("Mazes")

    # Build the main window and the frame.
    win = gtk.Window(gtk.WINDOW_TOPLEVEL)
    win.get_settings().set_string_property("gtk-font-name", "sans normal 10", "")
    # Icon is a pixbuf, which can be built with:
    # gdk-pixbuf-csource --raw --name=icon image.png
    try:
        icon = gtk.gdk.pixbuf_new_from_inline(len(Icon), Icon, False)
    except gobject.GError:
        print "String to pixbuf conversion failure."
        return 0
    gtk.window_set_default_icon(icon)

    # Set up the initial algorithm and maze id.
    a = Algonames.index(algo) if Flags["auto"] else WF
    m = 2 if Flags["maz"] else 0
    frame = Frame(win, a, m)
    win.show_all()

    # Handle the window close button.
    win.connect("destroy", lambda w: gtk.main_quit())

    # Add a timer to the main loop to kick off an automatic run.
    if Flags["auto"]:
        glib.timeout_add(1000, on_timeout_start, frame)

    # Main loop.
    gtk.main()

    # Wrap up and quit.
    if Flags["log"]:
        logging.shutdown()

    return 0

#
# Run the main program, possibly with profiling.
#
if __name__ == "__main__":
    # Run profiling code.
    if False:
        import hotshot
        prof = hotshot.Profile("mazes.stats")
        prof.runcall(main)
        prof.close()
        sys.exit()
    else:
        sys.exit(main())

#
# eof
#


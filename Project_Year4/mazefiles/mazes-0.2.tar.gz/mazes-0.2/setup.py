from distutils.core import setup
setup(name='mazes',
      version='0.2',
      py_modules=['mazes'],)

